# NEO PLUS IOS LUANCHER

iPhone-style Android launcher built with Kotlin + Jetpack Compose.

## Features
- **Real home screen**: scans every installed app, real icons (adaptive icons rendered as iOS squircles), real launching, auto-updates on install/uninstall.
- **Translucent**: wallpaper-theme window + frosted glass panels; optional window blur on Android 12+.
- **Dock**: 4 pinned apps (defaults to Phone / Messages / Browser / Camera). Long-press any app: shortcuts, Add/Remove from Dock, App Info, Uninstall.
- **Today View** (swipe right): clock, battery, calendar, storage widgets + real Android widgets via AppWidgetHost ("+ Widget", "Edit" to remove).
- **App Library** (swipe past the last page): auto categories, Recently Added, search, tap a category to open it.
- **Control Center** (swipe down from the top area, or tap the chevron top-right): Wi-Fi / Bluetooth / Data / Airplane panels, real flashlight, brightness, volume, Focus (DND), rotation lock, timer, alarm, calculator, camera, settings.
- **Spotlight search** (swipe down from the middle of the screen): apps + web.
- Home button returns to the first page; Back is swallowed like a real launcher.

## Build
JDK 17 + Android SDK 35, then `gradle assembleDebug`. The GitHub Actions workflow builds the APK and uploads it as an artifact.

## Setup on the phone
1. Install the APK, press Home, choose **NEO PLUS** and **Always**.
2. Accept the permission prompts on first launch.
3. For brightness/rotation, Focus mode and all-files access, tap the matching tile once - Android opens the page where you flip the switch.
