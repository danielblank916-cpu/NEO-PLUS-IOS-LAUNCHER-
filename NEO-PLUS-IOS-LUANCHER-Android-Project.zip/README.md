# NEO PLUS IOS LUANCHER

Android launcher starter project built with Kotlin and Jetpack Compose.

## Build
Use JDK 17 and Android SDK 35, then run `gradle assembleDebug`.

The GitHub Actions workflow builds the debug APK and uploads it as the artifact
`NEO-PLUS-IOS-LUANCHER.apk`.

This is a starter launcher interface. Android can offer it as a Home app, but it
does not yet launch every installed app or replace all features of a full launcher.
