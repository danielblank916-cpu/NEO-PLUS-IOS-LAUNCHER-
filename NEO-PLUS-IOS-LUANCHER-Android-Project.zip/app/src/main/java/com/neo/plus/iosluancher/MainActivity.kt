package com.neo.plus.iosluancher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { NeoLauncherScreen() } }
    }
}

private data class AppTile(val title: String, val icon: ImageVector, val color: Color)

@Composable
private fun NeoLauncherScreen() {
    val tiles = listOf(
        AppTile("Phone", Icons.Filled.Phone, Color(0xFF36C879)),
        AppTile("Messages", Icons.Filled.Chat, Color(0xFF2D9CDB)),
        AppTile("Photos", Icons.Filled.Photo, Color(0xFFB56BE8)),
        AppTile("Camera", Icons.Filled.CameraAlt, Color(0xFF596579)),
        AppTile("Calendar", Icons.Filled.CalendarMonth, Color(0xFFEF5350)),
        AppTile("Files", Icons.Filled.Folder, Color(0xFFFFB74D)),
        AppTile("Music", Icons.Filled.MusicNote, Color(0xFFE85D9E)),
        AppTile("Maps", Icons.Filled.Map, Color(0xFF39A98E)),
        AppTile("Store", Icons.Filled.Store, Color(0xFF4F7EF7)),
        AppTile("Settings", Icons.Filled.Settings, Color(0xFF7D8795))
    )
    var selectedApp by remember { mutableStateOf("") }
    val date = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())

    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF83C8F4), Color(0xFFB8C9F8), Color(0xFFF0BDE2)))
        ).padding(horizontal = 22.dp, vertical = 28.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Text(
                text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                fontSize = 48.sp, fontWeight = FontWeight.Light, color = Color(0xFF15243A)
            )
            Text(text = date, fontSize = 16.sp, color = Color(0xFF24344A))
            Spacer(modifier = Modifier.height(28.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.White.copy(alpha = 0.28f),
                shape = RoundedCornerShape(26.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("NEO PLUS", fontSize = 13.sp, letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold, color = Color(0xFF24344A))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Make today beautiful.", fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold, color = Color(0xFF15243A))
                }
            }
            Spacer(modifier = Modifier.height(26.dp))
            tiles.chunked(4).forEach { rowTiles ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    rowTiles.forEach { tile ->
                        Column(
                            modifier = Modifier.weight(1f).padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                onClick = { selectedApp = tile.title },
                                modifier = Modifier.size(58.dp),
                                shape = RoundedCornerShape(18.dp),
                                color = tile.color,
                                shadowElevation = 5.dp
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(tile.icon, contentDescription = tile.title,
                                        tint = Color.White, modifier = Modifier.size(30.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(7.dp))
                            Text(tile.title, color = Color(0xFF17243A), fontSize = 11.sp,
                                textAlign = TextAlign.Center, maxLines = 1)
                        }
                    }
                    repeat(4 - rowTiles.size) { Spacer(modifier = Modifier.weight(1f)) }
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            if (selectedApp.isNotEmpty()) {
                Text("$selectedApp shortcut selected", color = Color(0xFF24344A),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    textAlign = TextAlign.Center, fontSize = 12.sp)
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = Color.White.copy(alpha = 0.38f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 13.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    tiles.take(4).forEach { tile ->
                        Box(
                            modifier = Modifier.size(48.dp).clip(CircleShape).background(tile.color),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(tile.icon, contentDescription = tile.title, tint = Color.White,
                                modifier = Modifier.size(25.dp))
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text("NEO PLUS IOS LUANCHER", modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center, color = Color(0xFF24344A).copy(alpha = 0.8f),
                fontSize = 10.sp, letterSpacing = 1.sp)
        }
    }
}
