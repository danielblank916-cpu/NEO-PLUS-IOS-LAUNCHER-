package com.neo.plus.iosluancher

import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private data class Sys(val wifi: Boolean, val bt: Boolean, val airplane: Boolean, val dnd: Boolean, val autoRotate: Boolean)

private fun readSys(ctx: Context): Sys {
    val wifi = try {
        (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) { false }
    val bt = try {
        ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
    } catch (e: Exception) { false }
    val air = try {
        Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    } catch (e: Exception) { false }
    val dnd = try {
        val f = ctx.getSystemService(NotificationManager::class.java).currentInterruptionFilter
        f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    } catch (e: Exception) { false }
    val rot = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 1
    } catch (e: Exception) { true }
    return Sys(wifi, bt, air, dnd, rot)
}

private fun askWriteSettings(ctx: Context) {
    ctx.safeStart(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
}

@Composable
private fun RoundTile(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(62.dp).clip(CircleShape)
                .background(if (active) Color(0xFF0A84FF) else Color.White.copy(alpha = 0.22f))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1, style = ShadowStyle)
    }
}

@Composable
private fun TileCard(content: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), 0.24f).padding(16.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Top
    ) { content() }
}

@Composable
private fun SliderCard(icon: ImageVector, value: Float, onChange: (Float) -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), 0.24f).padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
        Slider(
            value = value, onValueChange = onChange, modifier = Modifier.weight(1f).padding(start = 10.dp),
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = Color.White,
                inactiveTrackColor = Color.White.copy(alpha = 0.3f)
            )
        )
    }
}

@Composable
fun ControlCenter(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var sys by remember { mutableStateOf(readSys(ctx)) }
    LaunchedEffect(Unit) {
        while (true) { sys = readSys(ctx); delay(1000) }
    }

    // Flashlight (real toggle through Camera2 torch, no permission needed)
    val cm = remember { ctx.getSystemService(CameraManager::class.java) }
    var torchOn by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val cb = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { torchOn = enabled }
        }
        try { cm.registerTorchCallback(cb, null) } catch (e: Exception) { }
        onDispose { try { cm.unregisterTorchCallback(cb) } catch (e: Exception) { } }
    }

    // Volume
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC) / maxVol.toFloat()) }

    // Brightness
    var bright by remember {
        mutableFloatStateOf(
            try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f }
            catch (e: Exception) { 0.5f }
        )
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)).consumeTouches().noRipple(onClose)
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 24.dp)
                .noRipple { },
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Control Center", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, style = ShadowStyle)

            TileCard {
                RoundTile(Icons.Filled.AirplanemodeActive, "Airplane", sys.airplane) {
                    ctx.safeStart(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)); onClose()
                }
                RoundTile(Icons.Filled.SignalCellularAlt, "Data", false) {
                    ctx.safeStart(Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                    else Settings.ACTION_DATA_ROAMING_SETTINGS)); onClose()
                }
                RoundTile(Icons.Filled.Wifi, "Wi-Fi", sys.wifi) {
                    ctx.safeStart(Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                    else Settings.ACTION_WIFI_SETTINGS)); onClose()
                }
                RoundTile(Icons.Filled.Bluetooth, "Bluetooth", sys.bt) {
                    ctx.safeStart(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); onClose()
                }
            }

            SliderCard(Icons.Filled.BrightnessHigh, bright) { v ->
                bright = v
                if (Settings.System.canWrite(ctx)) {
                    try {
                        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                            (v * 255).roundToInt().coerceIn(1, 255))
                    } catch (e: Exception) { }
                }
            }
            if (!Settings.System.canWrite(ctx)) {
                Text("Tap here to allow brightness & rotation control", color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp, modifier = Modifier.clickable { askWriteSettings(ctx); onClose() }.padding(horizontal = 8.dp))
            }

            SliderCard(Icons.Filled.VolumeUp, vol) { v ->
                vol = v
                try { am.setStreamVolume(AudioManager.STREAM_MUSIC, (v * maxVol).roundToInt(), 0) } catch (e: Exception) { }
            }

            TileCard {
                RoundTile(Icons.Filled.FlashlightOn, "Torch", torchOn) {
                    try {
                        val id = cm.cameraIdList.first {
                            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                        }
                        cm.setTorchMode(id, !torchOn)
                    } catch (e: Exception) { }
                }
                RoundTile(Icons.Filled.DoNotDisturbOn, "Focus", sys.dnd) {
                    val nm = ctx.getSystemService(NotificationManager::class.java)
                    if (nm.isNotificationPolicyAccessGranted) {
                        nm.setInterruptionFilter(
                            if (sys.dnd) NotificationManager.INTERRUPTION_FILTER_ALL
                            else NotificationManager.INTERRUPTION_FILTER_PRIORITY
                        )
                    } else {
                        ctx.safeStart(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); onClose()
                    }
                }
                RoundTile(Icons.Filled.ScreenRotation, "Rotation", sys.autoRotate) {
                    if (Settings.System.canWrite(ctx)) {
                        try {
                            Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION,
                                if (sys.autoRotate) 0 else 1)
                        } catch (e: Exception) { }
                    } else { askWriteSettings(ctx); onClose() }
                }
                RoundTile(Icons.Filled.Timer, "Timer", false) {
                    ctx.safeStart(Intent(AlarmClock.ACTION_SHOW_TIMERS)); onClose()
                }
            }

            TileCard {
                RoundTile(Icons.Filled.Alarm, "Alarm", false) {
                    ctx.safeStart(Intent(AlarmClock.ACTION_SHOW_ALARMS)); onClose()
                }
                RoundTile(Icons.Filled.Calculate, "Calculator", false) {
                    ctx.safeStart(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR)); onClose()
                }
                RoundTile(Icons.Filled.CameraAlt, "Camera", false) {
                    ctx.safeStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); onClose()
                }
                RoundTile(Icons.Filled.Settings, "Settings", false) {
                    ctx.safeStart(Intent(Settings.ACTION_SETTINGS)); onClose()
                }
            }
        }
    }
}
