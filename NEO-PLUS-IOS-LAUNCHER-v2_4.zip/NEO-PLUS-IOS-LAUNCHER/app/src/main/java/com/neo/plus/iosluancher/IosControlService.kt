package com.neo.plus.iosluancher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/** Small iOS-style vertical volume bar. */
private class HudView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC3A3A3C.toInt() }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF2FFFFFF.toInt() }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wave = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 2f * d }
    var level = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((54 * d).toInt(), (176 * d).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = w / 2f
        val rect = RectF(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, bg)
        c.save()
        c.clipPath(Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) })
        c.drawRect(0f, h * (1f - level), w, h, fill)
        c.restore()
        val col = if (level > 0.18f) 0xFF48484A.toInt() else 0xFFFFFFFF.toInt()
        icon.color = col; wave.color = col
        val cx = w / 2f - 3 * d
        val cy = h - 28 * d
        c.drawPath(Path().apply {
            moveTo(cx - 8 * d, cy - 4 * d); lineTo(cx - 3 * d, cy - 4 * d); lineTo(cx + 3 * d, cy - 9 * d)
            lineTo(cx + 3 * d, cy + 9 * d); lineTo(cx - 3 * d, cy + 4 * d); lineTo(cx - 8 * d, cy + 4 * d); close()
        }, icon)
        if (level > 0f) c.drawArc(RectF(cx + 1 * d, cy - 6 * d, cx + 11 * d, cy + 6 * d), -50f, 100f, false, wave)
        if (level > 0.5f) c.drawArc(RectF(cx - 2 * d, cy - 11 * d, cx + 14 * d, cy + 11 * d), -50f, 100f, false, wave)
    }
}

/**
 * - Volume buttons: consumed, so Android's volume panel never shows; the iOS bar is shown instead.
 * - Android notification shade: closed as soon as it opens, and the iOS Control Center opens instead.
 * Must be switched on once in Settings > Accessibility.
 */
class IosControlService : AccessibilityService() {
    private val main = Handler(Looper.getMainLooper())
    private var hud: HudView? = null
    private var hudShown = false
    private var lastShade = 0L
    private val hide = Runnable {
        hud?.animate()?.alpha(0f)?.setDuration(220)?.withEndAction { hud?.visibility = View.GONE }?.start()
        hudShown = false
    }

    companion object {
        /** Lets the assistant press Home / Back / Recents, lock the screen and take screenshots. */
        @Volatile
        var instance: IosControlService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val v = HudView(this)
        v.visibility = View.GONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        lp.x = (14 * resources.displayMetrics.density).toInt()
        try { getSystemService(WindowManager::class.java).addView(v, lp); hud = v } catch (e: Exception) { }
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        try { hud?.let { getSystemService(WindowManager::class.java).removeView(it) } } catch (e: Exception) { }
        hud = null
        super.onDestroy()
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        val dir = when (e.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> AudioManager.ADJUST_RAISE
            KeyEvent.KEYCODE_VOLUME_DOWN -> AudioManager.ADJUST_LOWER
            else -> return false
        }
        if (e.action == KeyEvent.ACTION_DOWN) adjust(dir)
        return true
    }

    private fun adjust(dir: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        var stream = when {
            am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
            am.isMusicActive -> AudioManager.STREAM_MUSIC
            else -> AudioManager.STREAM_RING
        }
        try { am.adjustStreamVolume(stream, dir, 0) } catch (e: Exception) {
            stream = AudioManager.STREAM_MUSIC
            try { am.adjustStreamVolume(stream, dir, 0) } catch (e2: Exception) { }
        }
        val max = am.getStreamMaxVolume(stream).coerceAtLeast(1)
        showHud(am.getStreamVolume(stream) / max.toFloat())
    }

    private fun showHud(level: Float) {
        val v = hud ?: return
        v.level = level
        main.removeCallbacks(hide)
        v.animate().cancel()
        v.visibility = View.VISIBLE
        v.alpha = 1f
        hudShown = true
        main.postDelayed(hide, 1600)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (event.packageName?.toString() != "com.android.systemui") return
        val cls = event.className?.toString() ?: return
        val shade = cls.contains("NotificationShade") || cls.contains("StatusBarWindow") ||
            cls.contains("QuickSettings") || cls.contains("QSPanel") || cls.contains("NotificationPanel")
        if (!shade) return
        val now = System.currentTimeMillis()
        if (now - lastShade < 800) return
        lastShade = now
        if (Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        else performGlobalAction(GLOBAL_ACTION_BACK)
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("open_cc", true)
        )
    }

    override fun onInterrupt() {}
}
