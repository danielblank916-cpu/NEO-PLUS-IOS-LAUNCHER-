package com.neo.plus.iosluancher

import android.content.Context
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import kotlin.math.log10
import kotlin.math.roundToInt

/**
 * Whole-phone volume from 0% to 200%.
 *
 * 0-100% is the phone's normal volume (the stream's volume steps). Above 100% the stream stays at its maximum and a
 * loudness boost is added on the phone's global audio output (200% = twice the amplitude, about +6 dB). Android lets an
 * app do this only through a global audio effect, which some phones ignore; [supported] turns false when this phone
 * refuses it, and then the volume simply stays at the normal 100% maximum.
 */
object VolumeBoost {
    private const val PREFS = "neo_assistant"
    private var fx: LoudnessEnhancer? = null

    @Volatile var supported = true
        private set

    /** Saved boost in percent: 100 (none) to 200. */
    fun boost(ctx: Context): Int =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("boost_pct", 100).coerceIn(100, 200)

    /** Puts the saved boost back on the phone's sound (call when the launcher or the accessibility service starts). */
    @Synchronized
    fun apply(ctx: Context) { applyPct(boost(ctx)) }

    /** Sets the boost (100-200). Returns false when this phone does not allow a boost above 100%. */
    @Synchronized
    fun setBoost(ctx: Context, pct: Int): Boolean {
        val p = pct.coerceIn(100, 200)
        val ok = applyPct(p)
        val saved = if (ok) p else 100
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("boost_pct", saved).apply()
        return ok
    }

    private fun applyPct(pct: Int): Boolean {
        if (pct <= 100) {
            try { fx?.enabled = false; fx?.release() } catch (e: Throwable) { }
            fx = null
            return true
        }
        return try {
            val e = fx ?: LoudnessEnhancer(0).also { fx = it } // session 0 = the phone's whole audio output
            e.setTargetGain((2000.0 * log10(pct / 100.0)).toInt()) // millibels: 200% = +6.02 dB
            e.enabled = true
            true
        } catch (t: Throwable) {
            try { fx?.release() } catch (e: Throwable) { }
            fx = null
            supported = false
            false
        }
    }

    /** Current volume as 0.0 - 2.0 (1.0 = the normal maximum). */
    fun level(ctx: Context, stream: Int = AudioManager.STREAM_MUSIC): Float {
        val b = boost(ctx)
        if (b > 100) return b / 100f
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getStreamVolume(stream) / am.getStreamMaxVolume(stream).coerceAtLeast(1).toFloat()
    }

    /** Sets the volume from 0.0 to 2.0 and returns the level that was really reached. */
    fun setLevel(ctx: Context, v: Float, stream: Int = AudioManager.STREAM_MUSIC): Float {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(stream).coerceAtLeast(1)
        val lv = v.coerceIn(0f, 2f)
        if (lv <= 1f) {
            setBoost(ctx, 100)
            try { am.setStreamVolume(stream, (lv * max).roundToInt().coerceIn(0, max), 0) } catch (e: Exception) { }
        } else {
            try { am.setStreamVolume(stream, max, 0) } catch (e: Exception) { }
            setBoost(ctx, ((lv * 100f) / 5f).roundToInt() * 5)
        }
        return level(ctx, stream)
    }
}
