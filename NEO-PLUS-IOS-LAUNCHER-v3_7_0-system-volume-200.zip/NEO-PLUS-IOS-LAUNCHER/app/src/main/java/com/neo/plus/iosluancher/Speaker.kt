package com.neo.plus.iosluancher

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.os.Bundle
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.tanh
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.Future
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Guesses what language a text is in. Chichewa (Chinyanja) is spelled the way it sounds and uses a small set of very
 * common words that do not exist in English, so counting them is a reliable signal for short messages.
 */
object LangGuess {
    private val chichewa = setOf(
        "muli", "bwanji", "zikomo", "kwambiri", "inde", "ayi", "chonde", "ndikufuna", "ndili", "uthenga", "moni", "pepani",
        "wanu", "watumiza", "tsopano", "lero", "mawa", "dzulo", "ndalama", "chakudya", "abambo", "amayi", "ndiwerenge",
        "werengani", "mukufuna", "tiyeni", "bwino", "koma", "tikuwonana", "madzulo", "masana", "ndipo", "kapena", "ntchito",
        "kunyumba", "galimoto", "sukulu", "wabwino", "ndiwe", "iwe", "inu", "ife", "iwo", "kodi", "chiyani", "liti", "kuti",
        "ndani", "ndikupita", "ndikubwera", "ndatumiza", "walandira", "analandira", "watumizidwa", "ndikuthokozani",
        "mwadzuka", "mwauka", "mwaswera", "ndili bwino", "zili bwanji", "tumizani", "ndithu", "mnzanga", "bambo", "mayi",
        "mwana", "anthu", "pano", "uko", "komwe", "chifukwa", "ndiye", "tidzakumana", "mutipatse", "ndikukuyembekezera"
    )

    /** Returns the Chichewa locale when the text looks Chichewa, otherwise null (use the phone's language). */
    fun detect(text: String): Locale? {
        val words = text.lowercase(Locale.ROOT).split(Regex("[^\\p{L}']+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return null
        val hits = words.count { it in chichewa }
        val strong = hits >= 2 || (hits == 1 && words.size <= 3)
        return if (strong) Locale("ny") else null
    }

    fun isChichewa(text: String) = detect(text) != null
}

/**
 * A natural, human-sounding voice from Google's Gemini speech models (needs a Gemini key). Falls back to the phone's
 * own voice when there is no key, no internet, or the text is in a language the cloud voice can't be trusted with.
 */
object NaturalVoice {
    class Cfg(val key: String, val voice: String)

    private val models = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
    const val RATE = 24000

    fun config(ctx: Context): Cfg? {
        val p = ctx.getSharedPreferences("neo_assistant", Context.MODE_PRIVATE)
        // The natural voice uses the Gemini key.
        val key = AiStore.key(ctx, Provider.GEMINI)
        if (key.isBlank()) return null
        val male = (p.getString("voice_gender", "female") ?: "female") == "male"
        return Cfg(key.trim(), if (male) "Charon" else "Aoede")
    }

    /** Voice loudness in percent, 50 to 200. */
    fun volume(ctx: Context): Int =
        ctx.getSharedPreferences("neo_assistant", Context.MODE_PRIVATE).getInt("voice_volume", 100).coerceIn(50, 200)

    /** Multiplies 16-bit mono PCM by [gain]; loud peaks are rounded off softly instead of being cut (no harsh crackle). */
    fun applyGain(pcm: ByteArray, gain: Float): ByteArray {
        if (abs(gain - 1f) < 0.01f) return pcm
        val out = ByteArray(pcm.size)
        var i = 0
        while (i + 1 < pcm.size) {
            val s = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)).toShort().toInt()
            var v = s / 32768f * gain
            val a = abs(v)
            if (a > 0.8f) v = (if (v < 0) -1f else 1f) * (0.8f + 0.2f * tanh((a - 0.8f) / 0.2f))
            val o = (v * 32767f).toInt().coerceIn(-32768, 32767)
            out[i] = (o and 0xFF).toByte()
            out[i + 1] = ((o shr 8) and 0xFF).toByte()
            i += 2
        }
        return out
    }

    fun gender(ctx: Context): String =
        ctx.getSharedPreferences("neo_assistant", Context.MODE_PRIVATE).getString("voice_gender", "female") ?: "female"

    /** Raw 16-bit mono PCM at 24 kHz. */
    fun synth(key: String, text: String, voice: String): ByteArray {
        var last: Exception? = null
        for (m in models) {
            try { return synthWith(m, key, text, voice) } catch (e: Exception) { last = e }
        }
        throw last ?: Exception("No voice")
    }

    private fun synthWith(model: String, key: String, text: String, voice: String): ByteArray {
        val prompt = "Say this in a warm, relaxed, natural voice, like a real person talking to a friend, with natural pacing: $text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject().put(
                            "voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
                        )
                    )
            ).toString()
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10_000
            c.readTimeout = 40_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (c.responseCode !in 200..299) throw Exception("Voice request failed (${c.responseCode})")
            val res = c.inputStream.bufferedReader().use { it.readText() }
            val data = JSONObject(res).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getJSONObject("inlineData").getString("data")
            val pcm = Base64.decode(data, Base64.DEFAULT)
            if (pcm.size < 2000) throw Exception("Empty audio")
            return pcm
        } finally {
            c.disconnect()
        }
    }
}

/**
 * One shared text-to-speech engine. Speaks sentence by sentence so the floating orb can show each sentence as a
 * subtitle while it is spoken. Chichewa is spoken with a Chichewa voice if the phone has one; most phones do not,
 * so it falls back to Swahili (closest widely available pronunciation), then to the phone's language.
 */
object Speaker {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var initFailed = false
    private var queued: (() -> Unit)? = null
    private var queuedGiveUp: (() -> Unit)? = null

    @Volatile
    var speaking = false
        private set

    /** Set when the spoken language had to be replaced by a different voice (shown to the user once). */
    @Volatile
    var voiceNote: String = ""
        private set

    private var batch = 0L
    private val sentences = HashMap<String, Pair<String, Boolean>>() // utteranceId -> (sentence, isLast)
    private var onSentence: ((String) -> Unit)? = null
    private var onFinished: (() -> Unit)? = null

    private var appCtx: Context? = null
    @Volatile private var naturalToken = 0L
    private var track: AudioTrack? = null
    private val pool = Executors.newFixedThreadPool(3)

    fun speak(ctx: Context, text: String, onStart: ((String) -> Unit)? = null, onDone: (() -> Unit)? = null) {
        val app = ctx.applicationContext
        appCtx = app
        main.post {
            if (text.isBlank()) { onDone?.invoke(); return@post }
            val cfg = NaturalVoice.config(app)
            if (cfg != null && !LangGuess.isChichewa(text)) speakNatural(app, text, cfg, onStart, onDone)
            else speakSystem(app, text, onStart, onDone)
        }
    }

    private fun speakSystem(app: Context, text: String, onStart: ((String) -> Unit)?, onDone: (() -> Unit)?) {
        if (ready) {
            say(text, onStart, onDone)
        } else if (initFailed) {
            onStart?.invoke(text)
            main.postDelayed({ onDone?.invoke() }, 1500L + text.length * 45L)
        } else {
            queued = { say(text, onStart, onDone) }
            queuedGiveUp = { onStart?.invoke(text); main.postDelayed({ onDone?.invoke() }, 1500L + text.length * 45L) }
            if (tts == null) init(app)
        }
    }

    /** Joins short sentences so the voice keeps its natural flow; each chunk is one subtitle. */
    private fun chunk(sentences: List<String>): List<String> {
        val out = mutableListOf<String>()
        var cur = ""
        for (s in sentences) {
            if (cur.isNotEmpty() && cur.length + s.length > 200) { out += cur; cur = s }
            else cur = if (cur.isEmpty()) s else "$cur $s"
        }
        if (cur.isNotEmpty()) out += cur
        return out
    }

    private fun speakNatural(app: Context, text: String, cfg: NaturalVoice.Cfg, onStart: ((String) -> Unit)?, onDone: (() -> Unit)?) {
        try { tts?.stop() } catch (e: Exception) { }
        sentences.clear()
        val chunks = chunk(split(text))
        if (chunks.isEmpty()) { onDone?.invoke(); return }
        val my = ++naturalToken
        speaking = true
        pool.execute {
            try {
                var next: Future<ByteArray>? = pool.submit<ByteArray> { NaturalVoice.synth(cfg.key, chunks[0], cfg.voice) }
                for (i in chunks.indices) {
                    if (naturalToken != my) return@execute
                    val pcm = try { next!!.get() } catch (e: Exception) { null }
                    next = if (i + 1 < chunks.size) pool.submit<ByteArray> { NaturalVoice.synth(cfg.key, chunks[i + 1], cfg.voice) } else null
                    if (naturalToken != my) return@execute
                    if (pcm == null) { // cloud voice failed: finish with the phone's own voice
                        val rest = chunks.subList(i, chunks.size).joinToString(" ")
                        main.post { if (naturalToken == my) { speaking = false; speakSystem(app, rest, onStart, onDone) } }
                        return@execute
                    }
                    main.post { if (naturalToken == my) onStart?.invoke(chunks[i]) }
                    playPcm(pcm, my)
                }
                main.post { if (naturalToken == my) { speaking = false; onDone?.invoke() } }
            } catch (e: Exception) {
                main.post { if (naturalToken == my) { speaking = false; onDone?.invoke() } }
            }
        }
    }

    private fun playPcm(raw: ByteArray, my: Long) {
        val pct = appCtx?.let { NaturalVoice.volume(it) } ?: 100
        val pcm = NaturalVoice.applyGain(raw, pct / 100f)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(NaturalVoice.RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = t
        try {
            t.write(pcm, 0, pcm.size)
            val frames = pcm.size / 2
            t.play()
            val limit = System.currentTimeMillis() + frames * 1000L / NaturalVoice.RATE + 2000L
            while (naturalToken == my && t.playbackHeadPosition < frames && System.currentTimeMillis() < limit) Thread.sleep(25)
        } finally {
            try { t.stop() } catch (e: Exception) { }
            try { t.release() } catch (e: Exception) { }
            if (track === t) track = null
        }
    }

    fun stop() {
        main.post {
            naturalToken++
            try { track?.pause(); track?.flush() } catch (e: Exception) { }
            try { tts?.stop() } catch (e: Exception) { }
            sentences.clear()
            speaking = false
            onSentence = null
            onFinished = null
        }
    }

    private fun init(app: Context) {
        tts = TextToSpeech(app) { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    ready = true
                    tts?.setOnUtteranceProgressListener(listener)
                    queued?.invoke()
                } else {
                    initFailed = true
                    tts = null
                    queuedGiveUp?.invoke()
                }
                queued = null
                queuedGiveUp = null
            }
        }
    }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            val e = sentences[utteranceId ?: return] ?: return
            main.post { onSentence?.invoke(e.first) }
        }

        override fun onDone(utteranceId: String?) = finish(utteranceId)

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) = finish(utteranceId)

        private fun finish(utteranceId: String?) {
            val e = sentences.remove(utteranceId ?: return) ?: return
            if (e.second) main.post {
                speaking = false
                val done = onFinished
                onFinished = null
                onSentence = null
                done?.invoke()
            }
        }
    }

    private fun say(text: String, onStart: ((String) -> Unit)?, onDone: (() -> Unit)?) {
        val engine = tts ?: run { onDone?.invoke(); return }
        val loc = pickLocale(engine, LangGuess.detect(text))
        engine.setLanguage(loc)
        applySystemVoice(engine, loc)
        val parts = split(text)
        if (parts.isEmpty()) { onDone?.invoke(); return }
        onSentence = onStart
        onFinished = onDone
        speaking = true
        val b = ++batch
        sentences.clear()
        // Volume: below 100% lowers the voice; above 100% routes it through a loudness booster (200% = twice as loud).
        val pct = appCtx?.let { NaturalVoice.volume(it) } ?: 100
        val params = Bundle()
        if (pct > 100) {
            val sid = boostSession(pct)
            if (sid != 0) params.putInt(TextToSpeech.Engine.KEY_PARAM_SESSION_ID, sid)
        } else {
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, pct / 100f)
        }
        parts.forEachIndexed { i, s ->
            val id = "neo_${b}_$i"
            sentences[id] = s to (i == parts.lastIndex)
            engine.speak(s, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, params, id)
        }
    }

    private var enhancer: LoudnessEnhancer? = null
    private var boostSessionId = 0

    /** An audio session with a loudness booster attached; the phone's voice is played through it. 0 when unavailable. */
    private fun boostSession(pct: Int): Int = try {
        val app = appCtx ?: throw IllegalStateException()
        if (boostSessionId == 0) boostSessionId = (app.getSystemService(Context.AUDIO_SERVICE) as AudioManager).generateAudioSessionId()
        if (enhancer == null) enhancer = LoudnessEnhancer(boostSessionId)
        enhancer?.setTargetGain((2000.0 * log10(pct / 100.0)).toInt()) // 200% = +6 dB = twice the amplitude
        enhancer?.enabled = true
        boostSessionId
    } catch (e: Exception) { 0 }

    /** "male", "female" or null when the voice name does not say. Google voice names carry #male_1 / #female_2 etc. */
    private fun genderOf(name: String): String? {
        val n = name.lowercase(Locale.ROOT)
        return when {
            Regex("(?<![a-z])female(?![a-z])").containsMatchIn(n) -> "female"
            Regex("(?<![a-z])male(?![a-z])").containsMatchIn(n) -> "male"
            else -> null
        }
    }

    /**
     * The phone's own voice, always of the chosen gender: only voices whose name says that gender are used, never
     * the other one. If this phone has none for the language, the normal voice is pitched down (male) or up (female).
     */
    private fun applySystemVoice(engine: TextToSpeech, loc: Locale) {
        try {
            val want = if (appCtx?.let { NaturalVoice.gender(it) } == "male") "male" else "female"
            val voices = engine.voices.orEmpty().filter {
                it.locale.language == loc.language && it.features?.contains("notInstalled") != true
            }
            val pick = voices.filter { genderOf(it.name) == want }
                .sortedWith(compareByDescending<android.speech.tts.Voice> { it.locale.country == loc.country }.thenByDescending { it.quality })
                .firstOrNull()
            engine.setSpeechRate(0.96f)
            if (pick != null) {
                engine.voice = pick
                engine.setPitch(1.0f)
            } else {
                // No tagged voice: keep clear of voices tagged with the opposite gender, then shift the pitch.
                val untagged = voices.filter { genderOf(it.name) == null }.maxByOrNull { it.quality }
                if (untagged != null) engine.voice = untagged
                engine.setPitch(if (want == "male") 0.78f else 1.15f)
                if (voiceNote.isBlank()) voiceNote = "This phone has no $want voice installed, so I changed the pitch of its normal voice."
            }
        } catch (e: Exception) { }
    }

    private fun available(e: TextToSpeech, l: Locale) = try {
        e.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE
    } catch (ex: Exception) { false }

    private fun pickLocale(e: TextToSpeech, wanted: Locale?): Locale {
        val phone = Locale.getDefault()
        val fallback = if (available(e, phone)) phone else Locale.ENGLISH
        if (wanted == null) { voiceNote = ""; return fallback }
        if (available(e, wanted)) { voiceNote = ""; return wanted }
        val sw = Locale("sw")
        if (available(e, sw)) {
            voiceNote = "No Chichewa voice is installed, so I read it with a Swahili voice."
            return sw
        }
        voiceNote = "No Chichewa voice is installed, so I read it with the phone's normal voice."
        return fallback
    }

    /** Sentences for subtitles; very long ones are cut at a word so the engine's length limit is never hit. */
    private fun split(text: String): List<String> {
        val clean = text
            .replace(Regex("https?://\\S+"), " ")
            .replace(Regex("[*_#`]+"), "")
            .replace(Regex("[ \\t]+"), " ")
            .trim()
        val out = mutableListOf<String>()
        clean.split(Regex("(?<=[.!?…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }.forEach { s ->
            var rest = s
            while (rest.length > 150) {
                val cut = rest.lastIndexOf(' ', 150).let { if (it < 50) 150 else it }
                out += rest.substring(0, cut).trim()
                rest = rest.substring(cut).trim()
            }
            if (rest.isNotEmpty()) out += rest
        }
        return out
    }
}

/**
 * Things that happen later and on their own (a text message was delivered, ...). Shows up in the open chat panel, is
 * spoken with subtitles when the floating orb is running (or when "read replies aloud" is on), and falls back to a toast
 * so the news is never lost.
 */
object Announcer {
    private val handlers = CopyOnWriteArrayList<(String) -> Unit>()

    fun register(h: (String) -> Unit) { if (!handlers.contains(h)) handlers.add(h) }
    fun unregister(h: (String) -> Unit) { handlers.remove(h) }

    fun say(ctx: Context, text: String) {
        val app = ctx.applicationContext
        Handler(Looper.getMainLooper()).post {
            handlers.forEach { try { it(text) } catch (e: Exception) { } }
            val orb = OrbService.instance
            if (orb != null) {
                orb.say(text)
            } else if (app.getSharedPreferences("neo_assistant", Context.MODE_PRIVATE).getBoolean("speak", false)) {
                Speaker.speak(app, text)
            } else if (handlers.isEmpty()) {
                Toast.makeText(app, text, Toast.LENGTH_LONG).show()
            }
        }
    }
}
