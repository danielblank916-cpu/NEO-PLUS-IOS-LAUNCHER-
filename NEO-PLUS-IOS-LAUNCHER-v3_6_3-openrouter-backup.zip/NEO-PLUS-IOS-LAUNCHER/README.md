# NEO PLUS IOS LUANCHER

iPhone-style Android launcher built with Kotlin + Jetpack Compose.

## Features
- **Real home screen**: scans every installed app, real icons (adaptive icons rendered as iOS squircles), real launching, auto-updates on install/uninstall.
- **Translucent**: wallpaper-theme window + frosted glass panels; optional window blur on Android 12+.
- **Default apps**: Phone, Messages, Safari (your default browser) and Camera sit in the dock on a fresh install. Long-press any app > **Remove from Home Screen** to delete it from the launcher (it stays installed and stays in the App Library; long-press it there > **Add to Home Screen** / **Add to Dock** to bring it back). **Uninstall** is offered for apps you installed yourself.
- **Dock**: 4 pinned apps. Long-press any app: shortcuts, Add/Remove from Dock, Remove from Home Screen, App Info, Uninstall.
- **Today View** (swipe right): clock, battery, calendar, storage widgets + real Android widgets via AppWidgetHost ("+ Widget", "Edit" to remove).
- **App Library** (swipe past the last page): auto categories, Recently Added, search, tap a category to open it.
- **iOS status bar**: Android's status bar is hidden and replaced by an iPhone one: time, SIM signal bars + network type (5G / LTE / 3G), Wi-Fi, airplane icon, "No SIM", and battery with the percentage inside (green charging, yellow Low Power, red under 20%).
- **Control Center (the only control panel)**: swipe DOWN from the top-right, or UP from the bottom centre. Notification Centre: swipe down from the top-left, or UP from the bottom left/right. If Android's own shade is pulled down the launcher closes it again.
  Tiles: Airplane, Mobile data, Wi-Fi, Bluetooth, rotation lock, Focus, brightness/volume, flashlight, timer, calculator, camera, **built-in screen recorder**, notes, QR, dark mode, Low Power.
- **Music player in Control Center**: tap the app icon in the Now Playing card to choose any installed music app. Play then starts everything on that player (running session -> its media service -> "play from search" -> opens the app). Prev / next / pause control it afterwards.
- **Spotlight search** (swipe down anywhere, or tap the Search pill above the dock): apps + web.
- Home button returns to the first page; Back is swallowed like a real launcher.

## Look & speed
- NEO PLUS logo as the app icon (adaptive, dark background, Apple-style squircle on supported launchers) and as a badge on the clock widget.
- Apple-style continuous-corner (squircle) icons, flat clean icons with no drop shadows, app zooms out of the icon you tap.
- Faster startup: icons are rendered in parallel, sized to your screen, and package changes are debounced.

## Build
JDK 17 + Android SDK 35, then `gradle assembleDebug`. The GitHub Actions workflow builds the APK and uploads it as an artifact.

## Setup on the phone
1. Install the APK, press Home, choose **NEO PLUS** and **Always**.
2. Accept the permission prompts on first launch.
3. For brightness/rotation, Focus mode and all-files access, tap the matching tile once - Android opens the page where you flip the switch.

## Real toggles (no Settings screens)
Wi-Fi, Bluetooth, Airplane, Mobile data, Dark mode and Low power switch directly. Each tries the normal Android API, then hidden
system APIs, then root. The app targets Android 9 behaviour so Android still allows Wi-Fi/Bluetooth switching for it.
- Stock Android 13/14 blocks Airplane and Mobile data for normal apps. They work with **root**, or when the APK is installed as a
  **system priv-app** (custom ROM): copy the APK to `/system/priv-app/NeoPlusLauncher/` and `rom/privapp-permissions-com.neo.plus.iosluancher.xml` to `/system/etc/permissions/`.
- Low power / Dark mode also work after one adb grant: `adb shell pm grant com.neo.plus.iosluancher android.permission.WRITE_SECURE_SETTINGS`.
- Notification Centre and the Control Center "Now Playing" card need Notification access once (the panel shows a button for it).
- Screen recording is built in: tap the tile, accept Android's one-time capture prompt, tap again (or the notification) to stop. Videos go to Movies/NeoRecordings. No audio is recorded.
- Notes and QR scanner tiles open the matching app installed on your phone.
- If a switch is blocked, the matching Android settings page opens instead.

## One-time adb grants (no root, makes Dark mode / Low Power work)
```
adb shell pm grant com.neo.plus.iosluancher android.permission.WRITE_SECURE_SETTINGS
adb shell pm grant com.neo.plus.iosluancher android.permission.READ_PHONE_STATE
```
Airplane mode and Mobile data still need root or the priv-app install on Android 10+ (Android does not allow them for any normal app).

## Icons
Phone, Messages, Camera, Chrome, Play Store and the voice Recorder are drawn as iPhone-style icons; every other app fills the iOS squircle. Icons are ~76 dp (iOS 26 size) with a glass sheen.

## iOS volume bar + no Android shade (Accessibility service)
Switch on **Settings > Accessibility > NEO PLUS iOS Controls** once (the launcher opens that page on first run).
- Volume buttons show an iOS vertical volume bar on the left and Android's volume panel is suppressed. It adjusts call, media (when playing) or ringer volume.
- If Android's notification shade / quick settings opens, it is closed immediately and the iOS Control Center opens instead.
The service does not read screen content.

## Home panel (v2.6)
The top of the first home page is a clean glass panel: big thin clock (follows your 12/24 h setting), weekday + date, and live weather (temperature, condition, high/low, place name) drawn with hand-made glyphs. Weather comes from Open-Meteo (no key needed) for the phone's last known location and refreshes every ~20 minutes; tap the weather to allow location if it was denied. Tap the time for alarms, the date for the calendar.

## Neo Plus Assistant (v2.7)
Tap the glowing orb next to Search. Say or type "Neo Plus Assistant, ..." (or just the command). (It also opens on the system assist / voice-command intent.)
- **Chat**: talks like Gemini or Siri through your own API key. Open the gear icon, open the **Gemini** or **OpenRouter** page, paste a key (aistudio.google.com/apikey or openrouter.ai/keys) and optionally change the model name. Each page keeps its own key and model. The key is stored on the phone only and sent only to that provider. History is kept (clear it with the bin icon). Mic button = voice input, speaker icon = read replies aloud.
- **Phone control**: open any app by name, call a contact or number (dials directly if the Phone permission is granted), prefill an SMS, set alarms and timers, flashlight, Wi-Fi / Bluetooth / Airplane / Mobile data / Dark mode / Low Power / Focus (same limits as the Control Center toggles), volume, brightness, media keys, web search, open links, navigate, open Settings pages, Control Center, and Home / Back / Recents / Lock / Screenshot (needs the NEO PLUS iOS Controls accessibility service).
- **Works without a key**: simple commands ("open Camera", "turn on the flashlight", "turn off Wi-Fi", "take a screenshot", "lock the screen") run instantly on the phone. Everything else goes to the AI model.
- Brightness needs "Modify system settings" once. Do Not Disturb needs its access page once. The assistant opens the right page if one is missing.

## v2.7 changes
- **Stays on NEO PLUS iOS Launcher**: with the accessibility service on, an iOS status bar (time + battery) is drawn over every app you open, so Android's own bar never shows. It hides in landscape so videos/games stay clean. If the stock Android home screen ever appears, you are sent straight back to NEO PLUS (Recents is left alone). No launcher layout was changed.
- **Neo Plus Assistant**: the assistant is renamed. Battery saver and dark mode are now also local voice/typed commands ("turn on battery saver", "dark mode off") that work even without an API key.
- **Device admin**: the first-run walkthrough now asks for device admin (lock-screen policy only; it cannot wipe data or change passwords). "Lock the screen" then locks instantly.
- **Direct Dark mode + Battery saver**: both flip without opening Settings, from Control Center and from the assistant. Android requires the WRITE_SECURE_SETTINGS permission for this and does not let device admin grant it, so grant it once:
  `adb shell pm grant com.neo.plus.iosluancher android.permission.WRITE_SECURE_SETTINGS`
  (on a PC, or on the phone with an adb app such as LADB). Rooted phones and device-owner installs get it automatically. Until then, tapping the switch shows a dialog with the command instead of opening Settings.

## Whole-phone launcher mode (v2.8)
Android does not let a normal app hide its own status bar / navigation bar inside other apps. Three layers get as close as possible:
1. **Always (accessibility on)**: iOS status bar + iOS home bar are drawn over every app, covering Android's bars. Works in landscape and fullscreen apps too (status bar on top, home bar on the bottom or on the side that holds Android's buttons). Home bar: swipe up = Home, swipe up and hold = Recents; on 3-button navigation tap left / middle / right = Back / Home / Recents.
2. **`sh grant-all.sh`** (computer + USB debugging): grants every permission, turns on the accessibility service, notification access, device admin, and sets NEO PLUS as default home in one go.
3. **`sh grant-all.sh --kiosk`**: makes NEO PLUS the device owner. Android then really hides its status and navigation bars in every app opened from the launcher, and auto-grants permissions to all apps. Say "turn off full-phone launcher mode" to the assistant to pause it, or "remove device owner" to give up device-owner status completely (do this before uninstalling). On a rooted phone, "turn on full-phone launcher mode" sets it up without a computer. `--kiosk` also switches to gesture navigation so no Android buttons remain. Needs a phone with no accounts signed in during setup. Add `--gesture` for gesture navigation.

## Setup without a computer
See `setup-on-phone.txt`: install the free LADB app, pair it with Wireless debugging (Android 11+), and paste the listed lines. It does everything `grant-all.sh` does, including full-phone mode.

## Enable assistant button (v3.1)
Open the assistant: if something is still off, an **Enable assistant** button appears above the text box. Each tap opens the next page you need: Display over other apps, then (Android 13+) App info > ⋮ > **Allow restricted settings**, then Accessibility > NEO PLUS iOS Controls, then Device admin. The button disappears once all are on. Android 13+ greys out Accessibility for apps installed from a file until "Allow restricted settings" is chosen; `grant-all.sh` does it for you.

## Rooted phones (v3.2)
NEO PLUS is built to run on a rooted phone. On first launch it asks for root once (Magisk / KernelSU prompt: allow) and then does everything itself: all permissions, WRITE_SECURE_SETTINGS (direct Dark mode / Battery saver), overlay + restricted settings, accessibility service, notification access, Do Not Disturb access, device admin, default home app, gesture navigation, and (if no accounts are signed in) device owner for full-phone launcher mode. The **Enable assistant** button also re-runs it. Without root the old adb / settings-page route still works.

## v3.4 additions: floating assistant, SMS delivery, notification reading, power off / unlock

**Floating assistant (orb).** Tap the wave icon in the assistant header, or say/type "start listening". A round NEO PLUS logo
floats above every app and the home screen, listens in the background and answers out loud. What it says appears as subtitles
directly under the logo. Needs "Display over other apps" and the microphone.
- ✕ on the logo removes it. "Goodbye" / "stop listening" or the Stop button in its notification also remove it.
- Tap the logo to mute / un-mute the microphone (tap while it talks to interrupt). Drag it to move it; the position is remembered.
- Grey ring = muted, green = listening, amber = thinking, blue = speaking.

**Text messages.** "Send a message to Mum saying I am on my way" sends the SMS for real (SEND_SMS permission) and then tells you
"sent", "delivered", or what went wrong. "Delivered" depends on the carrier sending delivery reports; if none arrives within
90 seconds you are told the message was sent but delivery is not confirmed.

**Notifications.** While the orb is running, a new notification makes it ask "New notification from X. Do you want me to read it?".
Say yes ("yes", "read it", "inde", "ndiyo") and it reads it, say no ("no", "skip", "ayi") and it moves on. Chichewa text is detected
automatically. Phones rarely have a Chichewa voice, so it is read with a Swahili voice if installed (understandable, not perfect).
To stop the questions without closing the orb, set `notif_ask` to false in the `neo_assistant` preferences.

**Power off.** "Turn off the phone". Order tried: root (Magisk `reboot -p`), system-app permission (SHUTDOWN / REBOOT, see `rom/`),
then the Android power menu (you tap Power off). Plain Android does not allow more than the power menu.

**Unlock.** "Unlock the phone" wakes the screen and shows the launcher over the lock screen. With no screen lock set the phone opens.
With a PIN / pattern / fingerprint, Android's own unlock prompt appears and you unlock it yourself. No app can type your PIN for you.

Speech recognition language follows the phone's language setting; Android's recogniser does not support Chichewa, so spoken
Chichewa is best-effort (typed Chichewa works in the chat panel).

## v3.5 changes
- Added the OpenRouter backend (alongside Gemini), chosen in the AI model settings.
- New assistant actions: `whatsapp`, `calendar` (read upcoming events), `weather` (here or any city, via Open-Meteo) and `lookup` (quick answers from Wikipedia, falling back to DuckDuckGo).
- The floating orb now speaks the result of calendar, weather and lookup requests.
- Live web search for both AI backends (Gemini Google Search grounding, OpenRouter web plugin). If search isn't available for a key or model, it answers without it.
- Orb: two ways to talk, switched by the TAP/WAKE badge on the orb. TAP = tap the logo, then speak (mic is off otherwise). WAKE = say "Hey Neo" then your request (or tap the logo to talk right away).
- Follow-up actions: the assistant can fetch information first (lookup, calendar, weather, news, stock, sports, read_sms, call_log, screen) and then answer or act on it, up to 3 rounds.
- New actions: read_sms, call_log, screen (reads on-screen text via accessibility), news, stock, sports, remember, forget.
- Several things in one message: the assistant answers every question and does every action in one reply; simple multi-command sentences ("open Camera and turn on the torch") also work without an AI key.
- Voice: choose Female or Male in the AI model settings, with a "Hear this voice" button. The natural human-sounding voice uses Google's Gemini speech (uses the key on the Gemini page, even when OpenRouter answers your questions). Without a key it uses the best installed phone voice of that gender.
- Messages: when a chat notification arrives the orb asks to read it; after reading it asks "Do you want to reply?", takes the reply by voice, reads it back and sends it into the same chat (WhatsApp, Messages and other apps with a built-in Reply) once confirmed. Also by voice any time: "read my messages", "reply to Mum saying I'm on my way".
- Screen sharing: the SEE badge on the orb (or "share my screen") sends a fresh screenshot with every request so the assistant can help with what is displayed; `look` takes a one-off screenshot. Needs the "NEO PLUS iOS Controls" accessibility service and Android 11+ for screenshots (older versions use on-screen text only). Sharing resets to off whenever the orb starts.

## v3.5.1 fix
- Multi-part questions ("who was the first president of Malawi and 2 + 2") are now answered part by part. The assistant answers general knowledge and maths itself, uses at most specific lookups, and never shows raw lookup text as the answer.

## v3.5.2 fix
- Live information: if web search fails for your key or model (quota, unsupported model), the assistant now says it could not check live information instead of silently answering from old knowledge. The prompt also tells it never to answer recent events from memory and to avoid Wikipedia lookups for anything current.

## v3.5.3: read ALL notifications
- Say or type "read my notifications" (works without an AI key) or "read my WhatsApp notifications": the assistant reads notifications from every app (email, news, system apps, chats) straight from the notification listener, without opening the notification panel. Recently dismissed ones are remembered too (last 100). New action: `read_notifications {count, app}`.
- Needs Notification access for NEO PLUS (the panel shows a button for it).

## v3.5.4: reply to any notification + last message
- Replies now work for every notification that has a Reply box (chat apps, email apps, etc.), not only chats: "reply to <name or app> saying ...". Notifications you can answer are marked [can reply] when read. If there is no Reply box, a text message is sent to the contact instead.
- "Check my last message" (also works without an AI key) reads the most recent text sent or received in Messages from the phone's SMS store. "Last message from Mum" gives the latest in that conversation, plus the last one in the other direction. Needs the SMS permission. Messages that exist only in RCS/chat features are not in the SMS store; those are reached through their notifications.

## v3.5.5: working without an AI key
- With no key, each part of a sentence is handled separately: phone commands, "read my last message", "read my notifications", maths ("what is 2 + 2" -> "2 + 2 is 4."), and short Wikipedia facts. If it cannot find a real answer it says so and suggests adding a free Gemini key, instead of pasting unrelated articles. Works in both the chat and the floating orb.

## v3.5.6: Google first
- Without an AI key, questions now go to Google first (answer box or top snippets, shown as "From Google: ..."), then Wikipedia, and it says so honestly if neither has an answer. Google can block automated requests, so this is best-effort; a free Gemini key gives real Google Search answers every time (Gemini's built-in Google Search).

## v3.5.7: search without opening Google
- The assistant's `web_search` action no longer opens the browser: it finds the answer on Google in the background and tells you. Opening a page happens only when you ask ("open google.com").

## v3.5.8: build fix
- Fixed the compile errors from the GitHub build: an extra closing brace in MainActivity.kt, Java classes (CallLog.Calls, Phone) used as values in Assistant.kt, and `return` inside expression-bodied functions (stock, sports).

## v3.5.9
- Fixed the last compile error (setSpeak name clash in AssistantViewModel).

## v3.6.0
- AI settings rebuilt: the Claude backend is removed. Gemini and OpenRouter now have separate pages, each with its own API key and model name, saved under its own name, so saving one never overwrites the other. A tick shows which one answers; tap the other page and its name to switch without retyping anything.
- Old settings are moved automatically on first start (Gemini/OpenRouter key and model go to their own page; a saved Claude key is dropped).
- Gemini page lists every model. Tap one to make it the main model; the ticked models take over automatically, top to bottom, when a model hits its free quota (429), is unavailable, or is overloaded. "Load all models from Google" fetches the full current list for your key.
- The separate "Gemini key for the natural voice" field is gone: the voice uses the Gemini page key.

## v3.6.1
- Voice volume slider in the AI model settings: 50% to 200%. Above 100% the natural voice is amplified (with soft peak limiting so it does not crackle) and the phone's own voice is routed through a loudness booster. Your phone's media volume is not changed.
- Gemini auto-switch made stricter: quota (429), "quota exceeded"/"resource exhausted" messages, a model your key cannot use (403), model not found (404) and overload (500/502/503/504) now all move on to the next ticked model. Only a real key error stops the chain. A model with no free quota at all ("limit: 0") is skipped for an hour.

## v3.6.2
- Full-screen edges: the launcher now draws to every physical edge of the screen, including the camera cut-out / notch area and the sides in landscape (cut-out mode "shortEdges" on Android 9-10, "always" on Android 11+), and tall screens are no longer letterboxed. Icons and panels still keep clear of the cut-out and system bars.

## v3.6.3
- When every Gemini model is out of quota (or still cooling down), the assistant now switches to OpenRouter automatically, using the key and model saved on the OpenRouter page. It switches back to Gemini by itself once a Gemini model has quota again. A tick on the Gemini page turns this backup on or off (on by default; it needs an OpenRouter key saved, and OpenRouter models may be paid).
