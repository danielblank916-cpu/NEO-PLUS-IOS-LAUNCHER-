package com.neo.plus.iosluancher

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Where the AI details live. Every provider (Gemini, OpenRouter) has its OWN key and model, saved under its own name,
 * so changing one never touches the other. Gemini also keeps a list of models: the chosen one is used first and the
 * others take over automatically, in order, when a model runs out of its free quota.
 */
object AiStore {
    const val PREFS = "neo_assistant"

    /** Shown before the live list is loaded from Google. */
    val BUILTIN_GEMINI = listOf(
        "gemini-3.5-flash-lite",
        "gemini-3.5-flash",
        "gemini-3.1-flash-lite",
        "gemini-flash-lite-latest",
        "gemini-flash-latest"
    )

    @Volatile private var appCtx: Context? = null

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Call once from every entry point (chat panel, floating orb) before reading settings. */
    fun bind(ctx: Context) {
        if (appCtx == null) appCtx = ctx.applicationContext
        migrate(ctx)
    }

    /** Moves the old single key/model slot into the slot of the provider it belonged to. Claude settings are dropped. */
    private fun migrate(ctx: Context) {
        val p = sp(ctx)
        if (p.getBoolean("ai_v2", false)) return
        val e = p.edit()
        val oldProvider = p.getString("provider", "GEMINI") ?: "GEMINI"
        val oldKey = p.getString("key", "") ?: ""
        val oldModel = p.getString("model", "") ?: ""
        when (oldProvider) {
            "OPENROUTER" -> { e.putString("key_OPENROUTER", oldKey); e.putString("model_OPENROUTER", oldModel) }
            "GEMINI" -> { e.putString("key_GEMINI", oldKey); e.putString("model_GEMINI", oldModel) }
            else -> e.putString("provider", "GEMINI") // Claude was removed: its key is of no use to Gemini
        }
        // The separate "natural voice" key was a Gemini key; it now simply becomes the Gemini key if there is none.
        val voiceKey = p.getString("voice_key", "") ?: ""
        if (voiceKey.isNotBlank() && p.getString("key_GEMINI", "").isNullOrBlank() && oldProvider != "GEMINI") {
            e.putString("key_GEMINI", voiceKey)
        }
        e.remove("key").remove("model").remove("voice_key")
        e.putBoolean("ai_v2", true)
        e.apply()
    }

    fun activeProvider(ctx: Context): Provider {
        migrate(ctx)
        return runCatching { Provider.valueOf(sp(ctx).getString("provider", "GEMINI") ?: "GEMINI") }.getOrDefault(Provider.GEMINI)
    }

    fun setActiveProvider(ctx: Context, p: Provider) { sp(ctx).edit().putString("provider", p.name).apply() }

    fun key(ctx: Context, p: Provider): String { migrate(ctx); return (sp(ctx).getString("key_${p.name}", "") ?: "").trim() }
    fun model(ctx: Context, p: Provider): String { migrate(ctx); return (sp(ctx).getString("model_${p.name}", "") ?: "").trim() }

    /** Saves ONE provider's details. The other provider's details are never touched. */
    fun save(ctx: Context, p: Provider, key: String, model: String) {
        sp(ctx).edit().putString("key_${p.name}", key.trim()).putString("model_${p.name}", model.trim()).apply()
    }

    // ---- OpenRouter as the backup when every Gemini model is out of quota ----------------------------------------

    fun orBackupOn(ctx: Context): Boolean = sp(ctx).getBoolean("or_backup", true)
    fun setOrBackup(ctx: Context, on: Boolean) { sp(ctx).edit().putBoolean("or_backup", on).apply() }

    /** OpenRouter key and model to use when Gemini has nothing left, or null if that is off or no key is saved. */
    fun openRouterBackup(): Pair<String, String>? {
        val ctx = appCtx ?: return null
        if (!orBackupOn(ctx)) return null
        val k = key(ctx, Provider.OPENROUTER)
        if (k.isBlank()) return null
        return k to model(ctx, Provider.OPENROUTER).ifBlank { Provider.OPENROUTER.defaultModel }
    }

    // ---- Gemini model list ------------------------------------------------------------------------------------

    /** Every Gemini model we know of: the list loaded from Google (if any) or the built-in one. */
    fun geminiModels(ctx: Context): List<String> {
        val saved = runCatching {
            val a = JSONArray(sp(ctx).getString("gemini_all", "[]") ?: "[]")
            List(a.length()) { a.getString(it) }
        }.getOrDefault(emptyList())
        return (if (saved.isEmpty()) BUILTIN_GEMINI else saved).distinct()
    }

    fun saveGeminiModels(ctx: Context, list: List<String>) {
        sp(ctx).edit().putString("gemini_all", JSONArray(list.distinct()).toString()).apply()
    }

    /** Models the person switched OFF for automatic switching. */
    fun geminiOff(ctx: Context): Set<String> = runCatching {
        val a = JSONArray(sp(ctx).getString("gemini_off", "[]") ?: "[]")
        List(a.length()) { a.getString(it) }.toSet()
    }.getOrDefault(emptySet())

    fun saveGeminiOff(ctx: Context, off: Set<String>) {
        sp(ctx).edit().putString("gemini_off", JSONArray(off.toList()).toString()).apply()
    }

    /** The chosen model first, then every other model that is switched on, in list order. */
    fun geminiChain(primary: String): List<String> {
        val ctx = appCtx ?: return listOf(primary)
        val off = geminiOff(ctx)
        return (listOf(primary) + geminiModels(ctx).filter { it !in off }).distinct()
    }

    /** Asks Google for every model this key can chat with (blocking: call off the main thread). */
    fun fetchGeminiModels(key: String): List<String> {
        val out = ArrayList<String>()
        var token = ""
        repeat(5) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200" +
                (if (token.isNotEmpty()) "&pageToken=" + Uri.encode(token) else "")
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 15_000
                c.readTimeout = 30_000
                c.setRequestProperty("x-goog-api-key", key)
                val code = c.responseCode
                val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    val msg = runCatching { JSONObject(text).optJSONObject("error")?.optString("message") }.getOrNull()
                    throw Llm.LlmException(if (code == 400 || code == 401 || code == 403) "The API key was rejected" + (msg?.let { ": $it" } ?: "") else "Request failed ($code)")
                }
                val j = JSONObject(text)
                val arr = j.optJSONArray("models")
                for (i in 0 until (arr?.length() ?: 0)) {
                    val m = arr!!.getJSONObject(i)
                    val methods = m.optJSONArray("supportedGenerationMethods")
                    var chat = false
                    for (k in 0 until (methods?.length() ?: 0)) if (methods!!.getString(k) == "generateContent") chat = true
                    val name = m.optString("name").removePrefix("models/")
                    if (chat && name.startsWith("gemini") && listOf("tts", "image", "embedding", "live", "audio", "aqa", "robotics", "computer-use", "learnlm").none { name.contains(it) }) {
                        out += name
                    }
                }
                token = j.optString("nextPageToken")
            } finally {
                c.disconnect()
            }
            if (token.isEmpty()) return out.distinct().sortedWith(compareByDescending<String> { it.contains("lite") }.thenBy { it })
        }
        return out.distinct()
    }
}
