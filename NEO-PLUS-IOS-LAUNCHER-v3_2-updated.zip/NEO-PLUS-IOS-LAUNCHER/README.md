# NEO PLUS IOS LUANCHER

iPhone-style Android launcher built with Kotlin + Jetpack Compose.

## Features
- **Real home screen**: scans every installed app, real icons (adaptive icons rendered as iOS squircles), real launching, auto-updates on install/uninstall.
- **Translucent**: wallpaper-theme window + frosted glass panels; optional window blur on Android 12+.
- **Default apps**: Phone, Messages, Safari (your default browser) and Camera sit in the dock on a fresh install. Long-press any app > **Remove from Home Screen** to delete it from the launcher (it stays installed and stays in the App Library; long-press it there > **Add to Home Screen** / **Add to Dock** to bring it back). **Uninstall** is offered for apps you installed yourself.
- **Dock**: 4 pinned apps. Long-press any app: shortcuts, Add/Remove from Dock, Remove from Home Screen, App Info, Uninstall.
- **Today View** (swipe right): clock, battery, calendar, storage widgets + real Android widgets via AppWidgetHost ("+ Widget", "Edit" to remove).
- **App Library** (swipe past the last page): auto categories, Recently Added, search, tap a category to open it.
- **iOS status bar**: Android's status bar is hidden and replaced by an iPhone one: time, SIM signal bars + network type (5G / LTE / 3G), Wi-Fi, airplane icon, "No SIM", and battery with the percentage inside (green charging, yellow Low Power, red under 20%).
- **Control Center (the only control panel)**: swipe DOWN from the top-right, or UP from the bottom centre. Notification Centre: swipe down from the top-left, or UP from the bottom left/right. If Android's own shade is pulled down the launcher closes it again.
  Tiles: Airplane, Mobile data, Wi-Fi, Bluetooth, rotation lock, Focus, brightness/volume, flashlight, timer, calculator, camera, **built-in screen recorder**, notes, QR, dark mode, Low Power.
- **Music player in Control Center**: tap the app icon in the Now Playing card to choose any installed music app. Play then starts everything on that player (running session -> its media service -> "play from search" -> opens the app). Prev / next / pause control it afterwards.
- **Spotlight search** (swipe down anywhere, or tap the Search pill above the dock): apps + web.
- Home button returns to the first page; Back is swallowed like a real launcher.

## Look & speed
- NEO PLUS logo as the app icon (adaptive, dark background, Apple-style squircle on supported launchers) and as a badge on the clock widget.
- Apple-style continuous-corner (squircle) icons, flat clean icons with no drop shadows, app zooms out of the icon you tap.
- Faster startup: icons are rendered in parallel, sized to your screen, and package changes are debounced.

## Build
JDK 17 + Android SDK 35, then `gradle assembleDebug`. The GitHub Actions workflow builds the APK and uploads it as an artifact.

## Setup on the phone
1. Install the APK, press Home, choose **NEO PLUS** and **Always**.
2. Accept the permission prompts on first launch.
3. For brightness/rotation, Focus mode and all-files access, tap the matching tile once - Android opens the page where you flip the switch.

## Real toggles (no Settings screens)
Wi-Fi, Bluetooth, Airplane, Mobile data, Dark mode and Low power switch directly. Each tries the normal Android API, then hidden
system APIs, then root. The app targets Android 9 behaviour so Android still allows Wi-Fi/Bluetooth switching for it.
- Stock Android 13/14 blocks Airplane and Mobile data for normal apps. They work with **root**, or when the APK is installed as a
  **system priv-app** (custom ROM): copy the APK to `/system/priv-app/NeoPlusLauncher/` and `rom/privapp-permissions-com.neo.plus.iosluancher.xml` to `/system/etc/permissions/`.
- Low power / Dark mode also work after one adb grant: `adb shell pm grant com.neo.plus.iosluancher android.permission.WRITE_SECURE_SETTINGS`.
- Notification Centre and the Control Center "Now Playing" card need Notification access once (the panel shows a button for it).
- Screen recording is built in: tap the tile, accept Android's one-time capture prompt, tap again (or the notification) to stop. Videos go to Movies/NeoRecordings. No audio is recorded.
- Notes and QR scanner tiles open the matching app installed on your phone.
- If a switch is blocked, the matching Android settings page opens instead.

## One-time adb grants (no root, makes Dark mode / Low Power work)
```
adb shell pm grant com.neo.plus.iosluancher android.permission.WRITE_SECURE_SETTINGS
adb shell pm grant com.neo.plus.iosluancher android.permission.READ_PHONE_STATE
```
Airplane mode and Mobile data still need root or the priv-app install on Android 10+ (Android does not allow them for any normal app).

## Icons
Phone, Messages, Camera, Chrome, Play Store and the voice Recorder are drawn as iPhone-style icons; every other app fills the iOS squircle. Icons are ~76 dp (iOS 26 size) with a glass sheen.

## iOS volume bar + no Android shade (Accessibility service)
Switch on **Settings > Accessibility > NEO PLUS iOS Controls** once (the launcher opens that page on first run).
- Volume buttons show an iOS vertical volume bar on the left and Android's volume panel is suppressed. It adjusts call, media (when playing) or ringer volume.
- If Android's notification shade / quick settings opens, it is closed immediately and the iOS Control Center opens instead.
The service does not read screen content.

## Home panel (v2.6)
The top of the first home page is a clean glass panel: big thin clock (follows your 12/24 h setting), weekday + date, and live weather (temperature, condition, high/low, place name) drawn with hand-made glyphs. Weather comes from Open-Meteo (no key needed) for the phone's last known location and refreshes every ~20 minutes; tap the weather to allow location if it was denied. Tap the time for alarms, the date for the calendar.

## Neo Plus Assistant (v2.7)
Tap the glowing orb next to Search. Say or type "Neo Plus Assistant, ..." (or just the command). (It also opens on the system assist / voice-command intent.)
- **Chat**: talks like Gemini or Siri through your own API key. Open the gear icon, pick **Gemini** or **Claude**, paste a key (aistudio.google.com/apikey or console.anthropic.com/settings/keys) and optionally change the model name. The key is stored on the phone only and sent only to that provider. History is kept (clear it with the bin icon). Mic button = voice input, speaker icon = read replies aloud.
- **Phone control**: open any app by name, call a contact or number (dials directly if the Phone permission is granted), prefill an SMS, set alarms and timers, flashlight, Wi-Fi / Bluetooth / Airplane / Mobile data / Dark mode / Low Power / Focus (same limits as the Control Center toggles), volume, brightness, media keys, web search, open links, navigate, open Settings pages, Control Center, and Home / Back / Recents / Lock / Screenshot (needs the NEO PLUS iOS Controls accessibility service).
- **Works without a key**: simple commands ("open Camera", "turn on the flashlight", "turn off Wi-Fi", "take a screenshot", "lock the screen") run instantly on the phone. Everything else goes to the AI model.
- Brightness needs "Modify system settings" once. Do Not Disturb needs its access page once. The assistant opens the right page if one is missing.

## v2.7 changes
- **Stays on NEO PLUS iOS Launcher**: with the accessibility service on, an iOS status bar (time + battery) is drawn over every app you open, so Android's own bar never shows. It hides in landscape so videos/games stay clean. If the stock Android home screen ever appears, you are sent straight back to NEO PLUS (Recents is left alone). No launcher layout was changed.
- **Neo Plus Assistant**: the assistant is renamed. Battery saver and dark mode are now also local voice/typed commands ("turn on battery saver", "dark mode off") that work even without an API key.
- **Device admin**: the first-run walkthrough now asks for device admin (lock-screen policy only; it cannot wipe data or change passwords). "Lock the screen" then locks instantly.
- **Direct Dark mode + Battery saver**: both flip without opening Settings, from Control Center and from the assistant. Android requires the WRITE_SECURE_SETTINGS permission for this and does not let device admin grant it, so grant it once:
  `adb shell pm grant com.neo.plus.iosluancher android.permission.WRITE_SECURE_SETTINGS`
  (on a PC, or on the phone with an adb app such as LADB). Rooted phones and device-owner installs get it automatically. Until then, tapping the switch shows a dialog with the command instead of opening Settings.

## Whole-phone launcher mode (v2.8)
Android does not let a normal app hide its own status bar / navigation bar inside other apps. Three layers get as close as possible:
1. **Always (accessibility on)**: iOS status bar + iOS home bar are drawn over every app, covering Android's bars. Works in landscape and fullscreen apps too (status bar on top, home bar on the bottom or on the side that holds Android's buttons). Home bar: swipe up = Home, swipe up and hold = Recents; on 3-button navigation tap left / middle / right = Back / Home / Recents.
2. **`sh grant-all.sh`** (computer + USB debugging): grants every permission, turns on the accessibility service, notification access, device admin, and sets NEO PLUS as default home in one go.
3. **`sh grant-all.sh --kiosk`**: makes NEO PLUS the device owner. Android then really hides its status and navigation bars in every app opened from the launcher, and auto-grants permissions to all apps. Say "turn off full-phone launcher mode" to the assistant to pause it, or "remove device owner" to give up device-owner status completely (do this before uninstalling). On a rooted phone, "turn on full-phone launcher mode" sets it up without a computer. `--kiosk` also switches to gesture navigation so no Android buttons remain. Needs a phone with no accounts signed in during setup. Add `--gesture` for gesture navigation.

## Setup without a computer
See `setup-on-phone.txt`: install the free LADB app, pair it with Wireless debugging (Android 11+), and paste the listed lines. It does everything `grant-all.sh` does, including full-phone mode.

## Enable assistant button (v3.1)
Open the assistant: if something is still off, an **Enable assistant** button appears above the text box. Each tap opens the next page you need: Display over other apps, then (Android 13+) App info > ⋮ > **Allow restricted settings**, then Accessibility > NEO PLUS iOS Controls, then Device admin. The button disappears once all are on. Android 13+ greys out Accessibility for apps installed from a file until "Allow restricted settings" is chosen; `grant-all.sh` does it for you.

## Rooted phones (v3.2)
NEO PLUS is built to run on a rooted phone. On first launch it asks for root once (Magisk / KernelSU prompt: allow) and then does everything itself: all permissions, WRITE_SECURE_SETTINGS (direct Dark mode / Battery saver), overlay + restricted settings, accessibility service, notification access, Do Not Disturb access, device admin, default home app, gesture navigation, and (if no accounts are signed in) device owner for full-phone launcher mode. The **Enable assistant** button also re-runs it. Without root the old adb / settings-page route still works.
