package com.neo.plus.iosluancher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.format.DateFormat
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.Date
import java.util.Locale

/** Small iOS-style vertical volume bar. */
private class HudView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC3A3A3C.toInt() }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF2FFFFFF.toInt() }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wave = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 2f * d }
    var level = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((54 * d).toInt(), (176 * d).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = w / 2f
        val rect = RectF(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, bg)
        c.save()
        c.clipPath(Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) })
        c.drawRect(0f, h * (1f - level), w, h, fill)
        c.restore()
        val col = if (level > 0.18f) 0xFF48484A.toInt() else 0xFFFFFFFF.toInt()
        icon.color = col; wave.color = col
        val cx = w / 2f - 3 * d
        val cy = h - 28 * d
        c.drawPath(Path().apply {
            moveTo(cx - 8 * d, cy - 4 * d); lineTo(cx - 3 * d, cy - 4 * d); lineTo(cx + 3 * d, cy - 9 * d)
            lineTo(cx + 3 * d, cy + 9 * d); lineTo(cx - 3 * d, cy + 4 * d); lineTo(cx - 8 * d, cy + 4 * d); close()
        }, icon)
        if (level > 0f) c.drawArc(RectF(cx + 1 * d, cy - 6 * d, cx + 11 * d, cy + 6 * d), -50f, 100f, false, wave)
        if (level > 0.5f) c.drawArc(RectF(cx - 2 * d, cy - 11 * d, cx + 14 * d, cy + 11 * d), -50f, 100f, false, wave)
    }
}

/**
 * iOS status bar drawn on top of every other app, so Android's own bar never shows while an app is open.
 * Solid black so the Android icons underneath are fully covered.
 */
private class StatusOverlayView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val bg = Paint().apply { color = Color.BLACK }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 15.5f * d; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xD9FFFFFF.toInt(); textSize = 12f * d; textAlign = Paint.Align.RIGHT
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x66FFFFFF; style = Paint.Style.STROKE; strokeWidth = 1f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    var time = ""
    var pct = 100
    var charging = false
    var lowPower = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, bg)
        val cy = h / 2f
        c.drawText(time, 22 * d, cy - (txt.ascent() + txt.descent()) / 2f, txt)

        val bw = 25 * d
        val bh = 12 * d
        val right = w - 22 * d
        val body = RectF(right - bw, cy - bh / 2f, right, cy + bh / 2f)
        c.drawRoundRect(body, 3.6f * d, 3.6f * d, outline)
        fill.color = when {
            charging -> 0xFF30D158.toInt()
            lowPower -> 0xFFFFD60A.toInt()
            pct <= 20 -> 0xFFFF453A.toInt()
            else -> Color.WHITE
        }
        val inner = RectF(body.left + 1.8f * d, body.top + 1.8f * d,
            body.left + 1.8f * d + (bw - 3.6f * d) * pct.coerceIn(0, 100) / 100f, body.bottom - 1.8f * d)
        if (inner.width() > 0f) c.drawRoundRect(inner, 2f * d, 2f * d, fill)
        c.drawRoundRect(RectF(body.right + 1.2f * d, cy - 2.2f * d, body.right + 2.8f * d, cy + 2.2f * d), 1f * d, 1f * d, fill.apply { color = 0x88FFFFFF.toInt() })
        c.drawText("$pct", body.left - 6 * d, cy - (small.ascent() + small.descent()) / 2f, small)
    }
}

/**
 * iOS home bar drawn over Android's navigation bar while another app is open (portrait AND landscape).
 * side: 0 = bottom, 1 = right edge, 2 = left edge (3-button navigation on a rotated phone).
 * Swipe toward the screen = Home, swipe and hold = recent apps, taps = Back / Home / Recents (button navigation only).
 */
private class NavOverlayView(ctx: Context, private val gesture: Boolean, private val side: Int, private val onAction: (Int) -> Unit) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val bg = Paint().apply { color = Color.BLACK }
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6FFFFFF.toInt() }
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, bg)
        val pl = 134 * d
        val pt = 5 * d
        when (side) {
            0 -> c.drawRoundRect(RectF((w - pl) / 2f, h - pt - 8 * d, (w + pl) / 2f, h - 8 * d), pt / 2f, pt / 2f, pill)
            1 -> c.drawRoundRect(RectF(w - pt - 8 * d, (h - pl) / 2f, w - 8 * d, (h + pl) / 2f), pt / 2f, pt / 2f, pill)
            else -> c.drawRoundRect(RectF(8 * d, (h - pl) / 2f, 8 * d + pt, (h + pl) / 2f), pt / 2f, pt / 2f, pill)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; downT = SystemClock.elapsedRealtime() }
            MotionEvent.ACTION_UP -> {
                val dx = e.x - downX
                val dy = e.y - downY
                val held = SystemClock.elapsedRealtime() - downT
                val inward = when (side) { 0 -> -dy; 1 -> -dx; else -> dx }
                val tap = Math.abs(dx) < 20 * d && Math.abs(dy) < 20 * d
                when {
                    inward > 40 * d -> onAction(if (held > 350) AccessibilityService.GLOBAL_ACTION_RECENTS else AccessibilityService.GLOBAL_ACTION_HOME)
                    tap && !gesture -> {
                        val f = if (side == 0) downX / width.coerceAtLeast(1) else downY / height.coerceAtLeast(1)
                        onAction(when {
                            side == 0 && f < 1f / 3 -> AccessibilityService.GLOBAL_ACTION_BACK
                            side == 0 && f < 2f / 3 -> AccessibilityService.GLOBAL_ACTION_HOME
                            side == 0 -> AccessibilityService.GLOBAL_ACTION_RECENTS
                            f < 1f / 3 -> AccessibilityService.GLOBAL_ACTION_RECENTS
                            f < 2f / 3 -> AccessibilityService.GLOBAL_ACTION_HOME
                            else -> AccessibilityService.GLOBAL_ACTION_BACK
                        })
                    }
                }
            }
        }
        return true
    }
}

/**
 * - Volume buttons: consumed, so Android's volume panel never shows; the iOS bar is shown instead.
 * - Android notification shade: closed as soon as it opens, and the iOS Control Center opens instead.
 * Must be switched on once in Settings > Accessibility.
 */
class IosControlService : AccessibilityService() {
    private val main = Handler(Looper.getMainLooper())
    private var hud: HudView? = null
    private var hudShown = false
    private var lastShade = 0L
    private var statusOverlay: StatusOverlayView? = null
    private var navOverlay: NavOverlayView? = null
    private var launcherFront = true
    private var lastBringBack = 0L
    private var imeCache: Set<String> = emptySet()
    private var imeAt = 0L
    private var homeCache: Set<String> = emptySet()
    private var homeAt = 0L
    private val tick = object : Runnable {
        override fun run() {
            refreshOverlay()
            main.postDelayed(this, 15_000)
        }
    }
    private val hide = Runnable {
        hud?.animate()?.alpha(0f)?.setDuration(220)?.withEndAction { hud?.visibility = View.GONE }?.start()
        hudShown = false
    }

    companion object {
        /** Lets the assistant press Home / Back / Recents, lock the screen and take screenshots. */
        @Volatile
        var instance: IosControlService? = null
    }

    private val shotExecutor = Executors.newSingleThreadExecutor()

    /** A JPEG of what is on the screen right now (Android 11+), scaled down; null if unavailable. Call off the main thread. */
    fun captureScreen(): ByteArray? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var out: ByteArray? = null
        try {
            takeScreenshot(android.view.Display.DEFAULT_DISPLAY, shotExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val hw = android.graphics.Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        val bmp = hw?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                        result.hardwareBuffer.close()
                        if (bmp != null) {
                            val scale = 1280f / maxOf(bmp.width, bmp.height)
                            val scaled = if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(
                                bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true
                            ) else bmp
                            val bos = ByteArrayOutputStream()
                            scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, bos)
                            out = bos.toByteArray()
                        }
                    } catch (e: Exception) {
                    } finally {
                        latch.countDown()
                    }
                }

                override fun onFailure(errorCode: Int) { latch.countDown() }
            })
            latch.await(5, TimeUnit.SECONDS)
        } catch (e: Exception) { }
        return out
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val v = HudView(this)
        v.visibility = View.GONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        lp.x = (14 * resources.displayMetrics.density).toInt()
        try { getSystemService(WindowManager::class.java).addView(v, lp); hud = v } catch (e: Exception) { }
        addStatusOverlay()
        addNavOverlay()
        main.post(tick)
    }

    // ---- iOS status bar over other apps ------------------------------------------------------

    private fun statusBarHeight(): Int {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var id = if (land) resources.getIdentifier("status_bar_height_landscape", "dimen", "android") else 0
        if (id <= 0) id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else (28 * resources.displayMetrics.density).toInt()
    }

    private fun addStatusOverlay() {
        val v = StatusOverlayView(this)
        v.visibility = View.GONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, statusBarHeight(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        try { getSystemService(WindowManager::class.java).addView(v, lp); statusOverlay = v } catch (e: Exception) { }
        refreshOverlay()
    }

    @Suppress("DEPRECATION")
    private fun addNavOverlay() {
        val dm = resources.displayMetrics
        val d = dm.density
        val gesture = try { Settings.Secure.getInt(contentResolver, "navigation_mode", 0) == 2 } catch (e: Exception) { false }
        val rot = try { getSystemService(WindowManager::class.java).defaultDisplay.rotation } catch (e: Exception) { 0 }
        val tablet = minOf(dm.widthPixels, dm.heightPixels) / d >= 600
        val side = when {
            gesture || tablet -> 0
            rot == android.view.Surface.ROTATION_90 -> 1
            rot == android.view.Surface.ROTATION_270 -> 2
            else -> 0
        }
        val v = NavOverlayView(this, gesture, side) { performGlobalAction(it) }
        v.visibility = View.GONE
        val lp: WindowManager.LayoutParams
        if (side == 0) {
            val name = if (gesture) "navigation_bar_gesture_height" else "navigation_bar_height"
            val id = resources.getIdentifier(name, "dimen", "android")
            val h = maxOf(((if (gesture) 22 else 48) * d).toInt(), if (id > 0) resources.getDimensionPixelSize(id) else 0)
            lp = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, h)
            lp.gravity = Gravity.BOTTOM or Gravity.START
        } else {
            val id = resources.getIdentifier("navigation_bar_width", "dimen", "android")
            val w = maxOf((48 * d).toInt(), if (id > 0) resources.getDimensionPixelSize(id) else 0)
            lp = overlayParams(w, WindowManager.LayoutParams.MATCH_PARENT)
            lp.gravity = (if (side == 1) Gravity.END else Gravity.START) or Gravity.TOP
        }
        try { getSystemService(WindowManager::class.java).addView(v, lp); navOverlay = v } catch (e: Exception) { }
        refreshOverlay()
    }

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    /** Rebuilds both bars (size and side depend on rotation). */
    private fun rebuildOverlays() {
        val wm = getSystemService(WindowManager::class.java)
        try { statusOverlay?.let { wm.removeView(it) } } catch (e: Exception) { }
        try { navOverlay?.let { wm.removeView(it) } } catch (e: Exception) { }
        statusOverlay = null
        navOverlay = null
        addStatusOverlay()
        addNavOverlay()
    }

    /** Updates the clock + battery and shows the bars whenever another app is in front: portrait, landscape and fullscreen apps. */
    private fun refreshOverlay() {
        val v = statusOverlay ?: return
        val show = !launcherFront
        if (show) {
            val pattern = if (DateFormat.is24HourFormat(this)) "HH:mm" else "h:mm"
            v.time = SimpleDateFormat(pattern, Locale.getDefault()).format(Date())
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (b != null) {
                val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                if (level >= 0) v.pct = level * 100 / scale
                val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                v.charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            }
            v.lowPower = try { (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isPowerSaveMode } catch (e: Exception) { false }
            v.invalidate()
        }
        v.visibility = if (show) View.VISIBLE else View.GONE
        navOverlay?.visibility = if (show) View.VISIBLE else View.GONE
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        rebuildOverlays()
    }

    private fun imePackages(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (now - imeAt > 60_000) {
            imeAt = now
            imeCache = try {
                getSystemService(InputMethodManager::class.java).enabledInputMethodList.map { it.packageName }.toSet()
            } catch (e: Exception) { emptySet() }
        }
        return imeCache
    }

    /** "package/Class" of the home screens of OTHER launchers (the stock Android launcher etc.). */
    private fun otherHomeActivities(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (now - homeAt > 60_000) {
            homeAt = now
            homeCache = try {
                packageManager.queryIntentActivities(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY
                ).map { it.activityInfo.packageName to it.activityInfo.name }
                    .filter { it.first != packageName && it.first != "com.android.settings" }
                    .map { it.first + "/" + it.second }.toSet()
            } catch (e: Exception) { emptySet() }
        }
        return homeCache
    }

    /** Remembers which app is in front, and pulls the user straight back if the stock Android home screen ever shows. */
    private fun trackForeground(pkg: String, cls: String) {
        if (pkg == packageName) { launcherFront = true; refreshOverlay(); return }
        if (pkg == "android" || pkg in imePackages()) return
        if ("$pkg/$cls" in otherHomeActivities()) {
            val now = System.currentTimeMillis()
            if (now - lastBringBack > 800) {
                lastBringBack = now
                startActivity(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                        .setClass(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            }
            return
        }
        launcherFront = false
        refreshOverlay()
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        main.removeCallbacks(tick)
        try { statusOverlay?.let { getSystemService(WindowManager::class.java).removeView(it) } } catch (e: Exception) { }
        statusOverlay = null
        try { navOverlay?.let { getSystemService(WindowManager::class.java).removeView(it) } } catch (e: Exception) { }
        navOverlay = null
        try { hud?.let { getSystemService(WindowManager::class.java).removeView(it) } } catch (e: Exception) { }
        hud = null
        super.onDestroy()
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        val dir = when (e.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> AudioManager.ADJUST_RAISE
            KeyEvent.KEYCODE_VOLUME_DOWN -> AudioManager.ADJUST_LOWER
            else -> return false
        }
        if (e.action == KeyEvent.ACTION_DOWN) adjust(dir)
        return true
    }

    private fun adjust(dir: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        var stream = when {
            am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
            am.isMusicActive -> AudioManager.STREAM_MUSIC
            else -> AudioManager.STREAM_RING
        }
        try { am.adjustStreamVolume(stream, dir, 0) } catch (e: Exception) {
            stream = AudioManager.STREAM_MUSIC
            try { am.adjustStreamVolume(stream, dir, 0) } catch (e2: Exception) { }
        }
        val max = am.getStreamMaxVolume(stream).coerceAtLeast(1)
        showHud(am.getStreamVolume(stream) / max.toFloat())
    }

    private fun showHud(level: Float) {
        val v = hud ?: return
        v.level = level
        main.removeCallbacks(hide)
        v.animate().cancel()
        v.visibility = View.VISIBLE
        v.alpha = 1f
        hudShown = true
        main.postDelayed(hide, 1600)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""
        if (pkg != "com.android.systemui") { trackForeground(pkg, cls); return }
        val shade = cls.contains("NotificationShade") || cls.contains("StatusBarWindow") ||
            cls.contains("QuickSettings") || cls.contains("QSPanel") || cls.contains("NotificationPanel")
        if (!shade) return
        val now = System.currentTimeMillis()
        if (now - lastShade < 800) return
        lastShade = now
        if (Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        else performGlobalAction(GLOBAL_ACTION_BACK)
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("open_cc", true)
        )
    }

    override fun onInterrupt() {}
}
