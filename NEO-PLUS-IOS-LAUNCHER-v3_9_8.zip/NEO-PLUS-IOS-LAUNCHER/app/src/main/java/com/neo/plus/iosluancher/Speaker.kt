package com.neo.plus.iosluancher

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import kotlin.math.min
import kotlin.math.sqrt
import android.util.LruCache
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Guesses what language a text is in. Chichewa (Chinyanja) is spelled the way it sounds and uses a small set of very
 * common words that do not exist in English, so counting them is a reliable signal for short messages.
 */
object LangGuess {
    private val chichewa = setOf(
        "muli", "bwanji", "zikomo", "kwambiri", "inde", "ayi", "chonde", "ndikufuna", "ndili", "uthenga", "moni", "pepani",
        "wanu", "watumiza", "tsopano", "lero", "mawa", "dzulo", "ndalama", "chakudya", "abambo", "amayi", "ndiwerenge",
        "werengani", "mukufuna", "tiyeni", "bwino", "koma", "tikuwonana", "madzulo", "masana", "ndipo", "kapena", "ntchito",
        "kunyumba", "galimoto", "sukulu", "wabwino", "ndiwe", "iwe", "inu", "ife", "iwo", "kodi", "chiyani", "liti", "kuti",
        "ndani", "ndikupita", "ndikubwera", "ndatumiza", "walandira", "analandira", "watumizidwa", "ndikuthokozani",
        "mwadzuka", "mwauka", "mwaswera", "ndili bwino", "zili bwanji", "tumizani", "ndithu", "mnzanga", "bambo", "mayi",
        "mwana", "anthu", "pano", "uko", "komwe", "chifukwa", "ndiye", "tidzakumana", "mutipatse", "ndikukuyembekezera"
    )

    /** Returns the Chichewa locale when the text looks Chichewa, otherwise null (use the phone's language). */
    fun detect(text: String): Locale? {
        val words = text.lowercase(Locale.ROOT).split(Regex("[^\\p{L}']+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return null
        val hits = words.count { it in chichewa }
        val strong = hits >= 2 || (hits == 1 && words.size <= 3)
        return if (strong) Locale("ny") else null
    }

    fun isChichewa(text: String) = detect(text) != null
}

/**
 * A natural, human-sounding voice from Google's Gemini speech models (needs a Gemini key). Falls back to the phone's
 * own voice when there is no key, no internet, or the text is in a language the cloud voice can't be trusted with.
 */
object NaturalVoice {
    class Cfg(val key: String, val voice: String)

    /** Gemini speech voices by gender. The chosen gender never uses a voice from the other list. */
    val FEMALE = listOf("Aoede", "Kore")
    val MALE = listOf("Charon", "Orus")

    /** The chosen voice first, then a second voice of the SAME gender to try if the first one fails. */
    private fun sameGender(voice: String): List<String> {
        val list = if (voice in MALE) MALE else FEMALE
        return listOf(voice) + list.filter { it != voice }
    }

    private val models = listOf("gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts")
    const val RATE = 24000

    fun config(ctx: Context): Cfg? {
        val p = ctx.getSharedPreferences("neo_assistant", Context.MODE_PRIVATE)
        migrateToGeminiOnly(p)
        KeyPool.attach(ctx)
        val key = p.getString("key", "") ?: ""
        if (key.isBlank()) return null
        val male = (p.getString("voice_gender", "female") ?: "female") == "male"
        return Cfg(key.trim(), if (male) MALE[0] else FEMALE[0])
    }

    fun gender(ctx: Context): String =
        ctx.getSharedPreferences("neo_assistant", Context.MODE_PRIVATE).getString("voice_gender", "female") ?: "female"

    /** Voices already made this session, so a repeated sentence ("Calling Mum") plays at once. About 8 MB at most. */
    private val cache = object : LruCache<String, ByteArray>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ByteArray) = value.size
    }

    /** Raw 16-bit mono PCM at 24 kHz. */
    fun synth(key: String, text: String, voice: String): ByteArray {
        val ck = voice + "|" + text
        cache.get(ck)?.let { return it }
        var last: Exception? = null
        for (v in sameGender(voice)) {
            for (m in models) {
                try {
                    val pcm = polish(KeyPool.run(key, m) { k -> synthWith(m, k, text, v) })
                    cache.put(ck, pcm)
                    return pcm
                } catch (e: Exception) { last = e }
            }
        }
        throw last ?: Exception("No voice")
    }

    private fun synthWith(model: String, key: String, text: String, voice: String): ByteArray {
        // Only the words to be spoken go to the voice model. An instruction such as "say this naturally" in the same
        // text is read out loud by the model ("speak in natural human voice..."), so there is none. The voice name
        // already decides how it sounds. Ending with a full stop stops the model from inventing a trailing sound.
        val spoken = text.trim().let { if (it.isNotEmpty() && it.last() !in ".!?…\"”)") it + "." else it }
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", spoken)))))
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject().put(
                            "voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
                        )
                    )
            ).toString()
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 6_000
            c.readTimeout = 25_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) {
                val err = try { c.errorStream?.bufferedReader()?.use { it.readText() } ?: "" } catch (e: Exception) { "" }
                KeyPool.limitFrom(code, err)?.let { throw it } // out of quota: the next key takes over
                if (KeyPool.rejectedFrom(code, err)) throw Llm.LlmException("The API key was rejected ($code)")
                throw Exception("Voice request failed ($code)")
            }
            val res = c.inputStream.bufferedReader().use { it.readText() }
            // The audio is not always in the first part of the reply: look through every part of every candidate.
            var data: String? = null
            val cands = JSONObject(res).optJSONArray("candidates")
            loop@ for (ci in 0 until (cands?.length() ?: 0)) {
                val parts = cands!!.optJSONObject(ci)?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                for (pi in 0 until parts.length()) {
                    val d = parts.optJSONObject(pi)?.optJSONObject("inlineData")?.optString("data").orEmpty()
                    if (d.isNotEmpty()) { data = d; break@loop }
                }
            }
            if (data == null) throw Exception("No audio in reply")
            val pcm = Base64.decode(data, Base64.DEFAULT)
            if (pcm.size < 2000) throw Exception("Empty audio")
            return pcm
        } finally {
            c.disconnect()
        }
    }

    /**
     * Cleans the end of every spoken piece. The voice model adds a hissy / static tail after the last word (it sounds
     * like a radio switching off). Walking back from the end, every frame that is quiet, or noise-like (hiss: lots of
     * zero crossings, little energy), is cut. Only 30 ms is kept after the last real word, then a quick smooth fade
     * out, and 200 ms of true silence is added so the player never stops on a sound.
     */
    internal fun polish(pcm: ByteArray): ByteArray {
        val n = pcm.size / 2
        val frame = RATE / 200 // 5 ms
        if (n < frame * 40) return pcm
        val s = ShortArray(n) { ((pcm[2 * it + 1].toInt() shl 8) or (pcm[2 * it].toInt() and 0xFF)).toShort() }
        val frames = n / frame
        val rms = DoubleArray(frames)
        val zcr = DoubleArray(frames)
        for (f in 0 until frames) {
            var acc = 0.0
            var cross = 0
            val from = f * frame
            for (i in from until from + frame) {
                acc += s[i].toDouble() * s[i]
                if (i > from && ((s[i] >= 0) != (s[i - 1] >= 0))) cross++
            }
            rms[f] = sqrt(acc / frame)
            zcr[f] = cross.toDouble() / frame
        }
        val ref = rms.sorted()[((frames - 1) * 0.9).toInt()]
        var end = n
        if (ref > 150) {
            val quiet = ref * 0.20
            val hissy = ref * 0.55
            var last = frames - 1
            while (last > 0 && (rms[last] < quiet || (zcr[last] > 0.25 && rms[last] < hissy))) last--
            end = min(n, (last + 1 + 6) * frame) // keep 30 ms after the last word
            // Hiss can be loud, so as a second rule nothing is kept more than 140 ms after the last voiced (vowel-like) frame.
            var voiced = -1
            for (f in frames - 1 downTo 0) if (zcr[f] < 0.18 && rms[f] >= ref * 0.25) { voiced = f; break }
            if (voiced >= 0) end = min(end, (voiced + 1) * frame + RATE * 140 / 1000)
        }
        val fadeOut = min(end, RATE * 70 / 1000)
        for (i in 0 until fadeOut) {
            val idx = end - 1 - i
            val g = i.toFloat() / fadeOut
            s[idx] = (s[idx] * g * g).toInt().toShort()
        }
        val fadeIn = min(end, RATE * 6 / 1000)
        for (i in 0 until fadeIn) s[i] = (s[i] * (i.toFloat() / fadeIn)).toInt().toShort()
        val pad = RATE * 200 / 1000
        val out = ByteArray((end + pad) * 2) // the padding stays zero = silence
        for (i in 0 until end) { out[2 * i] = (s[i].toInt() and 0xFF).toByte(); out[2 * i + 1] = (s[i].toInt() shr 8).toByte() }
        return out
    }
}

/**
 * One shared text-to-speech engine. Speaks sentence by sentence so the floating orb can show each sentence as a
 * subtitle while it is spoken. Chichewa is spoken with a Chichewa voice if the phone has one; most phones do not,
 * so it falls back to Swahili (closest widely available pronunciation), then to the phone's language.
 */
object Speaker {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var initFailed = false
    private var queued: (() -> Unit)? = null
    private var queuedGiveUp: (() -> Unit)? = null

    @Volatile
    var speaking = false
        private set

    /** Set when the spoken language had to be replaced by a different voice (shown to the user once). */
    @Volatile
    var voiceNote: String = ""
        private set

    private var batch = 0L
    private val sentences = HashMap<String, Pair<String, Boolean>>() // utteranceId -> (sentence, isLast)
    private var onSentence: ((String) -> Unit)? = null
    private var onFinished: (() -> Unit)? = null

    private var appCtx: Context? = null
    @Volatile private var naturalToken = 0L
    private var track: AudioTrack? = null
    private val pool = Executors.newFixedThreadPool(5)

    /** [natural] = false always uses the phone's own voice (no Gemini request). */
    fun speak(ctx: Context, text: String, onStart: ((String) -> Unit)? = null, onDone: (() -> Unit)? = null, natural: Boolean = true) {
        val app = ctx.applicationContext
        appCtx = app
        main.post {
            if (text.isBlank()) { onDone?.invoke(); return@post }
            // One voice for everything: when a Gemini key exists, command answers and announcements use the same Gemini
            // voice as chat replies (the phone's own voice is a different speaker and sounded like a second person).
            val cfg = NaturalVoice.config(app)
            if (cfg != null && !LangGuess.isChichewa(text)) speakNatural(app, text, cfg, onStart, onDone)
            else speakSystem(app, text, onStart, onDone)
        }
    }

    private fun speakSystem(app: Context, text: String, onStart: ((String) -> Unit)?, onDone: (() -> Unit)?) {
        if (ready) {
            say(text, onStart, onDone)
        } else if (initFailed) {
            onStart?.invoke(text)
            main.postDelayed({ onDone?.invoke() }, 1500L + text.length * 45L)
        } else {
            queued = { say(text, onStart, onDone) }
            queuedGiveUp = { onStart?.invoke(text); main.postDelayed({ onDone?.invoke() }, 1500L + text.length * 45L) }
            if (tts == null) init(app)
        }
    }

    /**
     * Joins short sentences so the voice keeps its natural flow; each chunk is one subtitle. The first chunk is short
     * so the voice can start quickly; the rest are longer because they are made while the first one is playing.
     */
    private fun chunk(sentences: List<String>): List<String> {
        val out = mutableListOf<String>()
        var cur = ""
        for (s in sentences) {
            val limit = if (out.isEmpty()) 60 else 220
            if (cur.isNotEmpty() && cur.length + s.length > limit) { out += cur; cur = s }
            else cur = if (cur.isEmpty()) s else "$cur $s"
        }
        if (cur.isNotEmpty()) out += cur
        return out
    }

    private fun speakNatural(app: Context, text: String, cfg: NaturalVoice.Cfg, onStart: ((String) -> Unit)?, onDone: (() -> Unit)?) {
        try { tts?.stop() } catch (e: Exception) { }
        try { track?.pause(); track?.flush() } catch (e: Exception) { }
        sentences.clear()
        val chunks = chunk(split(text))
        if (chunks.isEmpty()) { onDone?.invoke(); return }
        val my = ++naturalToken
        speaking = true
        // Every chunk is requested at once (the pool runs several together), so while one plays the next are ready.
        val jobs: List<Future<ByteArray>> = chunks.map { c -> pool.submit<ByteArray> { NaturalVoice.synth(cfg.key, c, cfg.voice) } }
        pool.execute {
            try {
                for (i in chunks.indices) {
                    if (naturalToken != my) { jobs.forEach { it.cancel(true) }; return@execute }
                    // The first words must not keep the user waiting: after 12 s the phone's own voice takes over.
                    val pcm = try { jobs[i].get(if (i == 0) 12L else 25L, TimeUnit.SECONDS) } catch (e: Exception) { null }
                    if (naturalToken != my) { jobs.forEach { it.cancel(true) }; return@execute }
                    if (pcm == null) { // cloud voice failed: finish with the phone's own voice
                        jobs.forEach { it.cancel(true) }
                        val rest = chunks.subList(i, chunks.size).joinToString(" ")
                        main.post { if (naturalToken == my) { speaking = false; speakSystem(app, rest, onStart, onDone) } }
                        return@execute
                    }
                    main.post { if (naturalToken == my) onStart?.invoke(chunks[i]) }
                    playPcm(pcm, my)
                }
                main.post { if (naturalToken == my) { speaking = false; onDone?.invoke() } }
            } catch (e: Exception) {
                main.post { if (naturalToken == my) { speaking = false; onDone?.invoke() } }
            }
        }
    }

    private fun playPcm(pcm: ByteArray, my: Long) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(NaturalVoice.RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = t
        try {
            t.write(pcm, 0, pcm.size)
            val frames = pcm.size / 2
            t.play()
            val limit = System.currentTimeMillis() + frames * 1000L / NaturalVoice.RATE + 2000L
            while (naturalToken == my && t.playbackHeadPosition < frames && System.currentTimeMillis() < limit) Thread.sleep(25)
        } finally {
            try { t.setVolume(0f) } catch (e: Exception) { }
            try { t.stop() } catch (e: Exception) { }
            try { t.release() } catch (e: Exception) { }
            if (track === t) track = null
        }
    }

    fun stop() {
        main.post {
            naturalToken++
            try { track?.pause(); track?.flush() } catch (e: Exception) { }
            try { tts?.stop() } catch (e: Exception) { }
            sentences.clear()
            speaking = false
            onSentence = null
            onFinished = null
        }
    }

    /** Starts Google's speech engine when it is installed (it sounds far more natural than most phone-maker engines), otherwise the phone's default. */
    private fun init(app: Context, engine: String? = "com.google.android.tts") {
        val onInit = TextToSpeech.OnInitListener { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    ready = true
                    tts?.setOnUtteranceProgressListener(listener)
                    queued?.invoke()
                    queued = null
                    queuedGiveUp = null
                } else if (engine != null) {
                    try { tts?.shutdown() } catch (e: Exception) { }
                    tts = null
                    init(app, null)
                } else {
                    initFailed = true
                    tts = null
                    queuedGiveUp?.invoke()
                    queued = null
                    queuedGiveUp = null
                }
            }
        }
        tts = try {
            if (engine != null) TextToSpeech(app, onInit, engine) else TextToSpeech(app, onInit)
        } catch (e: Exception) {
            if (engine != null) { init(app, null); return }
            null
        }
    }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            val e = sentences[utteranceId ?: return] ?: return
            main.post { onSentence?.invoke(e.first) }
        }

        override fun onDone(utteranceId: String?) = finish(utteranceId)

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) = finish(utteranceId)

        private fun finish(utteranceId: String?) {
            val e = sentences.remove(utteranceId ?: return) ?: return
            if (e.second) main.post {
                speaking = false
                val done = onFinished
                onFinished = null
                onSentence = null
                done?.invoke()
            }
        }
    }

    private fun say(text: String, onStart: ((String) -> Unit)?, onDone: (() -> Unit)?) {
        val engine = tts ?: run { onDone?.invoke(); return }
        val loc = pickLocale(engine, LangGuess.detect(text))
        engine.setLanguage(loc)
        applySystemVoice(engine, loc)
        val parts = split(text)
        if (parts.isEmpty()) { onDone?.invoke(); return }
        onSentence = onStart
        onFinished = onDone
        speaking = true
        val b = ++batch
        sentences.clear()
        parts.forEachIndexed { i, s ->
            val id = "neo_${b}_$i"
            sentences[id] = s to (i == parts.lastIndex)
            engine.speak(s, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
    }

    /** Best installed voice of the chosen gender. Never picks a voice that is tagged as the other gender. */
    private fun applySystemVoice(engine: TextToSpeech, loc: Locale) {
        try {
            val male = appCtx?.let { NaturalVoice.gender(it) } == "male"
            // Google voices carry the speaker in their name (en-us-x-iol-local). Known male / female speakers are used
            // even when the name has no "male" / "female" tag.
            val maleIds = setOf("iol", "iom", "tpd", "rjs", "gbb", "gbd", "ahs", "cfc")
            val femaleIds = setOf("iob", "iof", "iog", "sfg", "tpc", "tpf", "gba", "gbc", "gbg", "fis", "afs", "cmn")
            fun speaker(v: Voice) = v.name.split('-', '_').firstOrNull { it in maleIds || it in femaleIds }
            fun isFemale(v: Voice) = v.name.contains("female", ignoreCase = true) || speaker(v) in femaleIds
            fun isMale(v: Voice) = (v.name.contains("male", ignoreCase = true) && !v.name.contains("female", ignoreCase = true)) || speaker(v) in maleIds
            val installed = engine.voices?.filter {
                it.locale.language == loc.language && it.features?.contains("notInstalled") != true
            }.orEmpty()
            val tagged = installed.filter { if (male) isMale(it) else isFemale(it) }
            // Never a voice known to be the other gender; untagged voices only when nothing tagged exists.
            val candidates = when {
                tagged.isNotEmpty() -> tagged
                male -> installed.filter { !isFemale(it) }
                else -> installed.filter { !isMale(it) }
            }
            val pick: Voice? = candidates.sortedWith(
                compareByDescending<Voice> { !it.isNetworkConnectionRequired }
                    .thenByDescending { loc.country.isNotEmpty() && it.locale.country == loc.country }
                    .thenByDescending { it.quality }
            ).firstOrNull()
            engine.setSpeechRate(0.95f)
            if (pick != null) engine.voice = pick
            engine.setPitch(if (tagged.isNotEmpty()) 1.0f else if (male) 0.85f else 1.0f)
        } catch (e: Exception) { }
    }

    private fun available(e: TextToSpeech, l: Locale) = try {
        e.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE
    } catch (ex: Exception) { false }

    private fun pickLocale(e: TextToSpeech, wanted: Locale?): Locale {
        val phone = Locale.getDefault()
        val fallback = if (available(e, phone)) phone else Locale.ENGLISH
        if (wanted == null) { voiceNote = ""; return fallback }
        if (available(e, wanted)) { voiceNote = ""; return wanted }
        val sw = Locale("sw")
        if (available(e, sw)) {
            voiceNote = "No Chichewa voice is installed, so I read it with a Swahili voice."
            return sw
        }
        voiceNote = "No Chichewa voice is installed, so I read it with the phone's normal voice."
        return fallback
    }

    /** Sentences for subtitles; very long ones are cut at a word so the engine's length limit is never hit. */
    private fun split(text: String): List<String> {
        val clean = text
            .replace(Regex("https?://\\S+"), " ")
            .replace(Regex("[*_#`]+"), "")
            .replace(Regex("[ \\t]+"), " ")
            .trim()
        val out = mutableListOf<String>()
        clean.split(Regex("(?<=[.!?…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }.forEach { s ->
            var rest = s
            while (rest.length > 150) {
                val cut = rest.lastIndexOf(' ', 150).let { if (it < 50) 150 else it }
                out += rest.substring(0, cut).trim()
                rest = rest.substring(cut).trim()
            }
            if (rest.isNotEmpty()) out += rest
        }
        return out
    }
}

/**
 * Things that happen later and on their own (a text message was delivered, ...). Shows up in the open chat panel, is
 * spoken with subtitles when the floating orb is running (or when "read replies aloud" is on), and falls back to a toast
 * so the news is never lost.
 */
object Announcer {
    private val handlers = CopyOnWriteArrayList<(String) -> Unit>()

    fun register(h: (String) -> Unit) { if (!handlers.contains(h)) handlers.add(h) }
    fun unregister(h: (String) -> Unit) { handlers.remove(h) }

    fun say(ctx: Context, text: String) {
        val app = ctx.applicationContext
        Handler(Looper.getMainLooper()).post {
            handlers.forEach { try { it(text) } catch (e: Exception) { } }
            val orb = OrbService.instance
            if (orb != null) {
                orb.say(text)
            } else if (app.getSharedPreferences("neo_assistant", Context.MODE_PRIVATE).getBoolean("speak", false)) {
                Speaker.speak(app, text, natural = false)
            } else if (handlers.isEmpty()) {
                Toast.makeText(app, text, Toast.LENGTH_LONG).show()
            }
        }
    }
}
