package com.neo.plus.iosluancher

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** The "incoming call" from the assistant at the wake-up time. Answer = the night summary is spoken out loud. */
class WakeCallActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        if (!SleepMode.isOn(applicationContext) && !WakeRinger.ringing) { finish(); return }
        setContent { CallScreen(this) }
    }

    override fun onDestroy() {
        if (isFinishing) Speaker.stop()
        super.onDestroy()
    }
}

@Composable
private fun CallScreen(act: WakeCallActivity) {
    val ctx = LocalContext.current
    var stage by remember { mutableStateOf(0) } // 0 ringing, 1 connecting, 2 talking, 3 ended
    var text by remember { mutableStateOf("") }
    var secs by remember { mutableStateOf(0) }

    LaunchedEffect(stage) {
        if (stage == 0) {
            while (WakeRinger.ringing) delay(500)
            if (stage == 0) act.finish()   // nobody answered: the ringing timed out
        } else if (stage == 1 || stage == 2) {
            while (true) { delay(1000); secs++ }
        }
    }

    fun answer() {
        WakeRinger.stop()
        SleepMode.answered(ctx)
        stage = 1
        Thread {
            val r = SleepMode.report(ctx)
            Handler(Looper.getMainLooper()).post {
                text = r
                stage = 2
                Speaker.speak(ctx, r, onDone = { stage = 3 })
            }
        }.start()
    }

    fun decline() {
        WakeRinger.stop()
        SleepMode.answered(ctx)
        act.finish()
    }

    val status = when (stage) {
        0 -> "incoming call…"
        1 -> "connecting…"
        2 -> "%02d:%02d".format(secs / 60, secs % 60)
        else -> "call ended"
    }

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B1220), Color(0xFF000000))))
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 56.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painterResource(R.drawable.neo_icon), null,
                Modifier.size(112.dp).clip(CircleShape), contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(18.dp))
            Text("Neo Plus Assistant", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(status, color = Color.White.copy(alpha = 0.7f), fontSize = 16.sp)
            Spacer(Modifier.height(20.dp))
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (stage >= 2 && text.isNotBlank()) {
                    Text(
                        text, color = Color.White.copy(alpha = 0.92f), fontSize = 17.sp, lineHeight = 24.sp,
                        textAlign = TextAlign.Start, modifier = Modifier.verticalScroll(rememberScrollState())
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            if (stage == 0) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                    CallButton(Color(0xFFFF3B30), false, "Decline") { decline() }
                    CallButton(Color(0xFF34C759), true, "Answer") { answer() }
                }
            } else {
                Row(Modifier.fillMaxWidth(), Arrangement.Center) {
                    CallButton(Color(0xFFFF3B30), false, if (stage == 3) "Close" else "End call") { Speaker.stop(); act.finish() }
                }
            }
        }
    }
}

@Composable
private fun CallButton(color: Color, call: Boolean, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(72.dp).clip(CircleShape).background(color).clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(if (call) Icons.Filled.Call else Icons.Filled.CallEnd, label, tint = Color.White, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
    }
}
