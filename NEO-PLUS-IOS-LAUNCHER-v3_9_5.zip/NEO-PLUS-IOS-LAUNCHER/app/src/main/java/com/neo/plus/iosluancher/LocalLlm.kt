package com.neo.plus.iosluancher

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import java.text.DateFormat
import java.util.Date

/**
 * Offline chat with a Gemma model file (MediaPipe .task format, e.g. Gemma 3 1B int4) that the user picks once in the
 * assistant settings. The file is copied into the app's private storage. Everything runs on the phone: no internet,
 * no key. It cannot know recent facts, so live questions (weather, news, prices) are answered honestly as "needs internet".
 */
object LocalLlm {
    private const val FILE = "local_model.task"
    private const val PREFS = "neo_assistant"

    @Volatile private var engine: LlmInference? = null
    @Volatile private var loadedStamp = 0L

    fun file(ctx: Context) = File(ctx.filesDir, FILE)

    fun ready(ctx: Context): Boolean = file(ctx).let { it.exists() && it.length() > 50_000_000L }

    fun sizeMb(ctx: Context): Long = file(ctx).length() / (1024 * 1024)

    var Context.preferOffline: Boolean
        get() = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("offline_first", false)
        set(v) { getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("offline_first", v).apply() }

    fun online(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (e: Exception) { false }

    /** Copies the picked file into private storage (a 0.5 GB file takes a little while). Call from a background thread. */
    fun install(ctx: Context, uri: android.net.Uri): String {
        return try {
            val tmp = File(ctx.filesDir, "$FILE.part")
            ctx.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
                ?: return "Could not open that file"
            if (tmp.length() < 50_000_000L) { tmp.delete(); return "That file is too small to be a model" }
            synchronized(this) { try { engine?.close() } catch (e: Throwable) { }; engine = null }
            val dest = file(ctx)
            dest.delete()
            if (!tmp.renameTo(dest)) return "Could not save the model"
            "Offline model ready (${sizeMb(ctx)} MB)"
        } catch (e: Throwable) { "Could not copy the model: ${e.message}" }
    }

    @Synchronized
    private fun load(ctx: Context): LlmInference {
        engine?.let { return it }
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(file(ctx).absolutePath)
            .setMaxTokens(1024)
            .build()
        return LlmInference.createFromOptions(ctx.applicationContext, opts).also { engine = it }
    }

    /** history: (isUser, text) pairs starting with the user, the last one being the new question. Blocks; use a background thread. */
    fun answer(ctx: Context, history: List<Pair<Boolean, String>>): String {
        val llm = try { load(ctx) } catch (e: Throwable) {
            return "I couldn’t start the offline model (${e.message?.take(120) ?: "unknown error"}). Check that the file is a Gemma .task model."
        }
        val sys = "You are Neo Plus Assistant, a friendly assistant on the user's phone, running offline without internet. " +
            "It is ${DateFormat.getDateTimeInstance().format(Date())}. Answer in one to four short sentences, plain words, no markdown. " +
            "You cannot look anything up. If asked for live information (weather, news, scores, prices, anything recent) say you need the internet for that. " +
            "If you do not know, say so; never invent facts."
        val sb = StringBuilder()
        val turns = history.takeLast(5).map { it.first to it.second.take(500) }.dropWhile { !it.first }
        turns.forEachIndexed { i, (user, text) ->
            if (user) {
                sb.append("<start_of_turn>user\n")
                if (i == 0) sb.append(sys).append("\n\n") // the instructions go in the first user turn
                sb.append(text).append("<end_of_turn>\n")
            } else sb.append("<start_of_turn>model\n").append(text).append("<end_of_turn>\n")
        }
        if (sb.isEmpty()) sb.append("<start_of_turn>user\n").append(sys).append("<end_of_turn>\n")
        sb.append("<start_of_turn>model\n")
        return try {
            llm.generateResponse(sb.toString()).replace("<end_of_turn>", "").trim().ifEmpty { "I have no answer for that." }
        } catch (e: Throwable) { "The offline model failed: ${e.message?.take(120) ?: "error"}" }
    }
}
