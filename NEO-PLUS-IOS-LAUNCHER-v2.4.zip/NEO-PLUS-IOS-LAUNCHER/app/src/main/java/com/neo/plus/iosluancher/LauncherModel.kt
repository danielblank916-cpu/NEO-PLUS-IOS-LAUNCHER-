package com.neo.plus.iosluancher

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AppEntry(
    val label: String,
    val pkg: String,
    val activity: String,
    val category: String,
    val installTime: Long,
    val icon: ImageBitmap
)

data class AppGroup(val name: String, val apps: List<AppEntry>)

object Cat {
    const val RECENT = "Recently Added"
    const val SOCIAL = "Social"
    const val ENTERTAINMENT = "Entertainment"
    const val PRODUCTIVITY = "Productivity"
    const val GAMES = "Games"
    const val TRAVEL = "Travel & Maps"
    const val OTHER = "Utilities"
    val order = listOf(SOCIAL, ENTERTAINMENT, PRODUCTIVITY, GAMES, TRAVEL, OTHER)
}

fun buildGroups(apps: List<AppEntry>): List<AppGroup> {
    if (apps.isEmpty()) return emptyList()
    val result = mutableListOf<AppGroup>()
    result += AppGroup(Cat.RECENT, apps.sortedByDescending { it.installTime }.take(12))
    Cat.order.forEach { c ->
        val list = apps.filter { it.category == c }
        if (list.isNotEmpty()) result += AppGroup(c, list)
    }
    return result
}

private fun categoryOf(info: ApplicationInfo?): String = when (info?.category) {
    ApplicationInfo.CATEGORY_SOCIAL -> Cat.SOCIAL
    ApplicationInfo.CATEGORY_GAME -> Cat.GAMES
    ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> Cat.ENTERTAINMENT
    ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_NEWS -> Cat.PRODUCTIVITY
    ApplicationInfo.CATEGORY_MAPS -> Cat.TRAVEL
    else -> Cat.OTHER
}

/** Renders any app icon into an iOS-style full-bleed square (adaptive layers are scaled to fill). */
fun renderIcon(d: Drawable, px: Int): Bitmap {
    val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    if (d is AdaptiveIconDrawable) {
        val off = (px * 0.25f).toInt()
        d.background?.let { it.setBounds(-off, -off, px + off, px + off); it.draw(c) }
        d.foreground?.let { it.setBounds(-off, -off, px + off, px + off); it.draw(c) }
    } else {
        c.drawColor(android.graphics.Color.WHITE)
        val pad = (px * 0.12f).toInt()
        d.setBounds(pad, pad, px - pad, px - pad)
        d.draw(c)
    }
    return bmp
}

/** Loads every launchable app. Icons are rendered in parallel on all cores, sized to the screen density. */
private suspend fun queryApps(ctx: Context): List<AppEntry> = coroutineScope {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val px = (ctx.resources.displayMetrics.density * 78f).toInt().coerceIn(180, 320)
    pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo != null && it.activityInfo.packageName != ctx.packageName }
        .map { ri ->
            async(Dispatchers.Default) {
                val ai = ri.activityInfo
                val label = ri.loadLabel(pm)?.toString() ?: ai.packageName
                val time = try { pm.getPackageInfo(ai.packageName, 0).firstInstallTime } catch (e: Exception) { 0L }
                val bmp = try {
                    renderIcon(ri.loadIcon(pm), px)
                } catch (e: Exception) {
                    renderIcon(pm.defaultActivityIcon, px)
                }
                AppEntry(label, ai.packageName, ai.name, categoryOf(ai.applicationInfo), time, bmp.asImageBitmap())
            }
        }
        .awaitAll()
        .distinctBy { it.pkg + "/" + it.activity }
        .sortedBy { it.label.lowercase() }
}

private fun defaultDock(ctx: Context, apps: List<AppEntry>): List<String> {
    val pm = ctx.packageManager
    val intents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
        Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
    )
    val installed = apps.map { it.pkg }.toSet()
    return intents.mapNotNull {
        pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
    }.filter { it in installed }.distinct()
}

class LauncherViewModel(application: Application) : AndroidViewModel(application) {
    private val ctx: Context get() = getApplication<Application>()
    private val prefs = ctx.getSharedPreferences("neo_launcher", Context.MODE_PRIVATE)

    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set
    var dock by mutableStateOf<List<String>>(emptyList())
        private set

    init {
        reload()
    }

    private var reloadJob: Job? = null

    /** Debounced: a burst of package broadcasts only triggers one rescan. */
    fun reload(delayMs: Long = 0L) {
        reloadJob?.cancel()
        reloadJob = viewModelScope.launch {
            if (delayMs > 0) delay(delayMs)
            val list = withContext(Dispatchers.Default) { queryApps(ctx) }
            apps = list
            val saved = prefs.getString("dock", null)
            dock = if (saved != null) saved.split(",").filter { it.isNotBlank() } else defaultDock(ctx, list)
        }
    }

    private fun saveDock(list: List<String>) {
        dock = list
        prefs.edit().putString("dock", list.joinToString(",")).apply()
    }

    fun pin(pkg: String) {
        if (pkg in dock) return
        saveDock(if (dock.size < 4) dock + pkg else dock.dropLast(1) + pkg)
    }

    fun unpin(pkg: String) = saveDock(dock - pkg)
}
