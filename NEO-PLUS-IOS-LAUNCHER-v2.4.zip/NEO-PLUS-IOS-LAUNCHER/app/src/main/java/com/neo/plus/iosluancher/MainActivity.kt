package com.neo.plus.iosluancher

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle

class MainActivity : ComponentActivity() {

    private val vm: LauncherViewModel by viewModels()
    private lateinit var widgets: WidgetController
    private var homeTick by mutableIntStateOf(0)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            // runtime prompts done -> walk through the special-access screens one by one
            // onResume runs right after this and opens the first page
            getSharedPreferences("neo_launcher", MODE_PRIVATE).edit().putInt("special_step", 0).apply()
        }

    // Keeps the launcher in sync when apps are installed / removed / updated
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            vm.reload(400)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        widgets = WidgetController(this)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        setContent {
            MaterialTheme {
                LauncherRoot(vm, widgets, homeTick, ::setBlur)
            }
        }
        askPermissionsOnce()
    }

    override fun onStart() {
        super.onStart()
        widgets.start()
    }

    override fun onResume() {
        super.onResume()
        hideStatusBar()
        nextSpecialAccess()
    }

    /** The iOS status bar is drawn by the launcher itself, so the Android one stays hidden. */
    private fun hideStatusBar() {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.statusBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideStatusBar()
        } else if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            // Android's own notification shade / quick settings got pulled down: close it again,
            // the iOS Control Center is the only control panel.
            window.decorView.postDelayed({ collapseSystemPanels() }, 60)
        }
    }

    private fun collapseSystemPanels() {
        try {
            val sbm = getSystemService("statusbar")
            sbm.javaClass.getMethod("collapsePanels").invoke(sbm)
        } catch (e: Throwable) { }
    }

    /** One-time walk through the special access pages that cannot be granted with a normal prompt. */
    private fun nextSpecialAccess() {
        val prefs = getSharedPreferences("neo_launcher", MODE_PRIVATE)
        val step = prefs.getInt("special_step", -1)
        if (step < 0 || step > 2) return
        prefs.edit().putInt("special_step", step + 1).apply()
        when (step) {
            0 -> if (!Settings.System.canWrite(this))
                safeStart(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
                else nextSpecialAccess()
            1 -> if (!NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName))
                safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                else nextSpecialAccess()
            2 -> {
                val nm = getSystemService(android.app.NotificationManager::class.java)
                if (!nm.isNotificationPolicyAccessGranted)
                    safeStart(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }
    }

    override fun onStop() {
        widgets.stop()
        super.onStop()
    }

    override fun onDestroy() {
        try { unregisterReceiver(packageReceiver) } catch (e: Exception) { }
        super.onDestroy()
    }

    // Home button pressed while the launcher is already open -> back to the first home page
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) homeTick++
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        widgets.onActivityResult(requestCode, resultCode, data)
    }

    /** Blurs the wallpaper behind overlays on devices that support window blur (Android 12+). */
    private fun setBlur(radius: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        try {
            val lp = window.attributes
            if (radius > 0) window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            lp.blurBehindRadius = radius
            window.attributes = lp
        } catch (e: Exception) { }
    }

    private fun askPermissionsOnce() {
        val prefs = getSharedPreferences("neo_launcher", MODE_PRIVATE)
        if (prefs.getBoolean("perms_asked_v2", false)) return
        prefs.edit().putBoolean("perms_asked_v2", true).apply()
        val list = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,   // SIM signal + network type in the iOS status bar
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) {
            list += Manifest.permission.POST_NOTIFICATIONS
            list += Manifest.permission.READ_MEDIA_AUDIO
            list += Manifest.permission.READ_MEDIA_IMAGES
            list += Manifest.permission.READ_MEDIA_VIDEO
        } else {
            list += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (Build.VERSION.SDK_INT >= 31) list += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT <= 28) list += Manifest.permission.WRITE_EXTERNAL_STORAGE
        permLauncher.launch(list.toTypedArray())
    }
}
