package com.neo.plus.iosluancher

import android.annotation.SuppressLint
import android.app.UiModeManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telephony.TelephonyManager
import android.widget.Toast

internal inline fun attempt(block: () -> Boolean): Boolean = try { block() } catch (e: Throwable) { false }

/**
 * Real on/off switches (no Settings screens). Each switch tries, in order:
 *  1. the direct Android API (works on older Android targets / system apps / device owners),
 *  2. hidden system APIs (work when the app is installed as a privileged system app, e.g. in a custom ROM),
 *  3. root (`su`) shell commands.
 * Only if all of them fail does the user get a short message.
 */
object Toggles {
    private const val MSG = "Android blocks this switch for normal apps. See README > Real toggles."

    private fun toast(ctx: Context, msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_LONG).show()
        }
    }

    private fun background(ctx: Context, action: () -> Boolean) {
        Thread {
            if (!attempt(action)) toast(ctx, MSG)
        }.start()
    }

    private fun su(cmd: String): Boolean = attempt {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        p.waitFor() == 0
    }

    private fun flag(on: Boolean, a: String, b: String) = if (on) a else b

    fun setWifi(ctx: Context, on: Boolean) = background(ctx) {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val ok = attempt { wm.setWifiEnabled(on) }
        ok || su("svc wifi ${flag(on, "enable", "disable")}")
    }

    @SuppressLint("MissingPermission")
    fun setBluetooth(ctx: Context, on: Boolean) = background(ctx) {
        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
        @Suppress("DEPRECATION")
        val ok = attempt {
            if (adapter == null) false else if (on) adapter.enable() else adapter.disable()
        }
        ok || su("svc bluetooth ${flag(on, "enable", "disable")}")
    }

    fun setAirplane(ctx: Context, on: Boolean) = background(ctx) {
        val ok = attempt {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            ConnectivityManager::class.java.getMethod("setAirplaneMode", java.lang.Boolean.TYPE).invoke(cm, on)
            true
        }
        ok ||
            su("cmd connectivity airplane-mode ${flag(on, "enable", "disable")}") ||
            su("settings put global airplane_mode_on ${flag(on, "1", "0")}; am broadcast -a android.intent.action.AIRPLANE_MODE")
    }

    fun setMobileData(ctx: Context, on: Boolean) = background(ctx) {
        val ok = attempt {
            val tm = ctx.getSystemService(TelephonyManager::class.java)
            TelephonyManager::class.java.getMethod("setDataEnabled", java.lang.Boolean.TYPE).invoke(tm, on)
            true
        }
        ok || su("svc data ${flag(on, "enable", "disable")}")
    }

    fun setDarkMode(ctx: Context, on: Boolean) = background(ctx) {
        val ok = attempt {
            if (Build.VERSION.SDK_INT >= 29) {
                val um = ctx.getSystemService(UiModeManager::class.java)
                // setNightModeActivated is a @SystemApi (hidden), so call it via reflection
                UiModeManager::class.java
                    .getMethod("setNightModeActivated", java.lang.Boolean.TYPE)
                    .invoke(um, on) as? Boolean ?: false
            } else false
        }
        ok || su("cmd uimode night ${flag(on, "yes", "no")}")
    }

    fun setLowPower(ctx: Context, on: Boolean) = background(ctx) {
        val ok = attempt {
            Settings.Global.putInt(ctx.contentResolver, "low_power", if (on) 1 else 0)
            true
        }
        ok || su("settings put global low_power ${flag(on, "1", "0")}")
    }
}
