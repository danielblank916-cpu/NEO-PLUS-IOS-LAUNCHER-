package com.neo.plus.iosluancher

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/** Device-admin hook for Neo Plus Assistant. Gives the assistant a reliable "lock the screen" and lets it keep working while locked-down apps are open. */
class NeoDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(context.applicationContext, "Neo Plus Assistant is now a device admin", Toast.LENGTH_SHORT).show()
        }
        // If the phone was set up with this app as device owner, this also hands it the secure-settings permission.
        Thread { SecureAccess.ensure(context.applicationContext) }.start()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(context.applicationContext, "Neo Plus Assistant device admin turned off", Toast.LENGTH_SHORT).show()
        }
    }
}

object DeviceAdmin {
    fun component(ctx: Context) = ComponentName(ctx, NeoDeviceAdminReceiver::class.java)

    private fun dpm(ctx: Context) = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    fun isActive(ctx: Context): Boolean = attempt { dpm(ctx).isAdminActive(component(ctx)) }

    fun requestIntent(ctx: Context): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component(ctx))
            .putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Lets Neo Plus Assistant lock your screen when you ask. It cannot erase data or change your password."
            )

    /** Locks the screen straight away. Needs the device admin to be active. */
    fun lockNow(ctx: Context): Boolean = attempt {
        if (!isActive(ctx)) false else { dpm(ctx).lockNow(); true }
    }
}

/**
 * WRITE_SECURE_SETTINGS is what lets Dark mode and Battery saver flip directly (no Settings screen).
 * Android never lets an app give this permission to itself, so [ensure] tries every on-device route:
 *  - already granted (adb grant, priv-app install) -> done
 *  - root (`su -c pm grant`)
 *  - device owner (`dpm set-device-owner`) -> the app grants the permission to itself
 */
object SecureAccess {
    const val PERM = "android.permission.WRITE_SECURE_SETTINGS"

    fun has(ctx: Context): Boolean =
        ctx.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED

    fun adbCommand(ctx: Context) = "adb shell pm grant ${ctx.packageName} $PERM"

    fun ensure(ctx: Context): Boolean {
        if (has(ctx)) return true
        attempt {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "pm grant ${ctx.packageName} $PERM"))
            p.waitFor() == 0
        }
        if (has(ctx)) return true
        attempt {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (dpm.isDeviceOwnerApp(ctx.packageName)) {
                dpm.setPermissionGrantState(
                    DeviceAdmin.component(ctx), ctx.packageName, PERM,
                    DevicePolicyManager.PERMISSION_GRANT_STATE_GRANTED
                )
            } else false
        }
        return has(ctx)
    }
}
