package com.neo.plus.iosluancher

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Runs a small Gemma model (for example Gemma3-1b-it-int4.task, Google's MediaPipe format) on the phone itself.
 *
 *  - It is only a plain-text chat helper: it cannot search the web, see the screen or press buttons, so website tasks,
 *    Excel work and phone actions stay on Gemini. Phone commands (open an app, flashlight, calls...) never reach any model.
 *  - Two ways to use it (assistant settings): as a back-up whenever Gemini is busy / out of quota / unreachable, or for
 *    ALL chat answers (no Gemini requests at all).
 *  - The model file (about 500 MB) is copied once into the app's private storage, because MediaPipe needs a real file path.
 *  - The model is loaded when first needed and released again after a few idle minutes to give the phone its memory back.
 */
object OfflineLlm {
    private const val PREFS = "neo_assistant"
    private const val MIN_BYTES = 100L * 1024 * 1024
    private const val MAX_TOKENS = 1280          // prompt + answer together
    private const val PROMPT_CHARS = 2600        // the prompt is kept short so the answer has room
    private const val TURN_CHARS = 700
    private const val IDLE_MS = 4 * 60_000L

    /** Shown in the settings screen while the file is copied / after it finished or failed. */
    var status by mutableStateOf("")
    var busyImporting by mutableStateOf(false)
        private set
    /** Bumped when the model is installed or removed so the settings screen refreshes. */
    var version by mutableStateOf(0)
        private set

    private val main = Handler(Looper.getMainLooper())
    private var engine: LlmInference? = null
    private var lastUse = 0L
    private var idleScheduled = false
    @Volatile var lastError: String = ""
        private set

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun modelFile(ctx: Context) = File(File(ctx.applicationContext.filesDir, "offline"), "gemma.task")

    fun installed(ctx: Context): Boolean = modelFile(ctx).let { it.exists() && it.length() >= MIN_BYTES }

    fun sizeMb(ctx: Context): Long = modelFile(ctx).length() / (1024 * 1024)

    /** Use the offline model when Gemini cannot answer (default on). */
    fun fallbackOn(ctx: Context) = prefs(ctx).getBoolean("offline_fallback", true)
    fun setFallback(ctx: Context, on: Boolean) { prefs(ctx).edit().putBoolean("offline_fallback", on).apply() }

    /** Use the offline model for every chat answer (default off). */
    fun alwaysOn(ctx: Context) = prefs(ctx).getBoolean("offline_always", false)
    fun setAlways(ctx: Context, on: Boolean) { prefs(ctx).edit().putBoolean("offline_always", on).apply() }

    fun fallbackReady(ctx: Context) = installed(ctx) && fallbackOn(ctx)
    fun alwaysReady(ctx: Context) = installed(ctx) && alwaysOn(ctx)

    /* ------------------------------------------------------------------ installing */

    /** Copies the picked .task file into private storage. Blocking: call from a background thread. Returns a message for the user. */
    fun importModel(ctx: Context, uri: Uri): String {
        if (busyImporting) return "Already copying a model file."
        val app = ctx.applicationContext
        busyImporting = true
        val dir = File(app.filesDir, "offline").apply { mkdirs() }
        val tmp = File(dir, "gemma.part")
        try {
            var total = -1L
            try {
                app.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) total = c.getLong(0)
                }
            } catch (e: Exception) { }
            if (total > 0 && dir.usableSpace < total + 50L * 1024 * 1024)
                return "Not enough free space on the phone: the model needs about ${total / (1024 * 1024)} MB."
            val input = app.contentResolver.openInputStream(uri) ?: return "Couldn't open that file."
            var done = 0L
            var lastShown = 0L
            input.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(1024 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (done - lastShown >= 8L * 1024 * 1024) {
                            lastShown = done
                            status = "Copying the model… " + (done / (1024 * 1024)) + (if (total > 0) " / ${total / (1024 * 1024)}" else "") + " MB"
                        }
                    }
                }
            }
            if (tmp.length() < MIN_BYTES) {
                val kb = tmp.length() / 1024
                tmp.delete()
                return "That file is only $kb KB, too small to be a Gemma model. Pick Gemma3-1b-it-int4.task."
            }
            release()
            val dest = modelFile(app)
            dest.delete()
            if (!tmp.renameTo(dest)) { tmp.copyTo(dest, overwrite = true); tmp.delete() }
            lastError = ""
            version++
            return "Offline model installed (${dest.length() / (1024 * 1024)} MB)."
        } catch (e: Throwable) {
            tmp.delete()
            return "Couldn't copy the model: ${e.message?.take(100) ?: e.javaClass.simpleName}"
        } finally {
            busyImporting = false
        }
    }

    fun remove(ctx: Context): String {
        release()
        val ok = modelFile(ctx).delete()
        version++
        return if (ok) "Offline model removed." else "No offline model was installed."
    }

    /* ------------------------------------------------------------------ answering */

    private val systemText: String
        get() {
            val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.getDefault()).format(Date())
            return "You are Neo Plus Assistant on an Android phone. You are running OFFLINE on the phone right now, so you cannot search the web, " +
                "check news, scores, prices or anything recent, read messages, see the screen or control the phone. If asked for those, say briefly that " +
                "you can't do that while offline and that it will work when Gemini is available. Answer everything else naturally and briefly, in plain " +
                "text with no markdown, in the language the user writes in. Now: $now (${TimeZone.getDefault().id})."
        }

    /**
     * Answers from the chat so far (alternating user / assistant turns). Returns null when no model is installed or it
     * could not run (the reason is in [lastError]). Blocking, slow on weak phones: call from a background thread.
     */
    @Synchronized
    fun reply(ctx: Context, history: List<Pair<Boolean, String>>, style: String? = null): String? {
        if (!installed(ctx)) return null
        return try {
            val llm = engine ?: create(ctx).also { engine = it }
            lastUse = System.currentTimeMillis()
            scheduleIdle()
            val raw = llm.generateResponse(buildPrompt(history, style))
            lastUse = System.currentTimeMillis()
            val text = clean(raw)
            if (text.isBlank()) { lastError = "The offline model returned no text."; null } else { lastError = ""; text }
        } catch (e: Throwable) {
            lastError = e.message?.take(120) ?: e.javaClass.simpleName
            try { engine?.close() } catch (x: Throwable) { }
            engine = null
            null
        }
    }

    private fun create(ctx: Context): LlmInference {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile(ctx).absolutePath)
            .setMaxTokens(MAX_TOKENS)
            .setPreferredBackend(LlmInference.Backend.CPU)
            .build()
        return LlmInference.createFromOptions(ctx.applicationContext, options)
    }

    /** Gemma chat format. Gemma has no system role, so the instructions go at the start of the first user turn. */
    private fun buildPrompt(history: List<Pair<Boolean, String>>, style: String?): String {
        // Merge consecutive turns of the same speaker and shorten long ones (action results can be long).
        val turns = ArrayList<Pair<Boolean, String>>()
        history.forEach { (user, text) ->
            val t = text.trim().let { if (it.length > TURN_CHARS) it.take(TURN_CHARS) + "…" else it }
            if (t.isEmpty()) return@forEach
            val last = turns.lastOrNull()
            if (last != null && last.first == user) turns[turns.lastIndex] = user to (last.second + "\n" + t) else turns += user to t
        }
        // Keep the newest turns that fit; the conversation must start with the user.
        var total = turns.sumOf { it.second.length }
        while (turns.size > 1 && (total > PROMPT_CHARS || !turns.first().first)) {
            total -= turns.removeAt(0).second.length
        }
        if (turns.isEmpty() || !turns.first().first) turns.add(0, true to "Hello")
        val sys = systemText + (if (style.isNullOrBlank()) "" else " " + style.trim().take(400))
        val sb = StringBuilder()
        turns.forEachIndexed { i, (user, text) ->
            sb.append("<start_of_turn>").append(if (user) "user" else "model").append('\n')
            if (i == 0) sb.append(sys).append("\n\n")
            sb.append(text).append("<end_of_turn>\n")
        }
        sb.append("<start_of_turn>model\n")
        return sb.toString()
    }

    private val tagRe = Regex("\\[\\[do:.*?\\]\\]", RegexOption.DOT_MATCHES_ALL)

    private fun clean(raw: String?): String =
        (raw ?: "").replace("<end_of_turn>", "").replace("<start_of_turn>", "").replace(tagRe, "")
            .replace("**", "").replace(Regex("(?m)^\\s*[*-]\\s+"), "• ").trim()

    /* ------------------------------------------------------------------ memory */

    private fun scheduleIdle() {
        if (idleScheduled) return
        idleScheduled = true
        main.postDelayed({
            idleScheduled = false
            if (engine != null) {
                if (System.currentTimeMillis() - lastUse >= IDLE_MS) Thread { release() }.start() else scheduleIdle()
            }
        }, IDLE_MS)
    }

    /** Frees the model's memory (it is loaded again on the next question). */
    @Synchronized
    fun release() {
        try { engine?.close() } catch (e: Throwable) { }
        engine = null
    }
}
