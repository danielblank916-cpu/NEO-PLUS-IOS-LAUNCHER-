package com.neo.plus.iosluancher

import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Keeps secrets (the Gemini API keys) encrypted in SharedPreferences with an Android Keystore AES-GCM key, the same way
 * [SiteVault] protects website logins. The key material never leaves the phone's secure hardware.
 *
 *  - [get] decrypts. A value saved by an older version (plain text) is read as it is and encrypted on the spot (migration).
 *  - [put] encrypts. If the Keystore is unusable on some ROM the value is saved as before, so the app keeps working.
 *  - A value that can no longer be decrypted (Keystore reset, restored from another phone) reads as "", i.e. "add your key again".
 */
object Secrets {
    private const val ALIAS = "neo_api_key_vault"
    private const val TAG = "enc1:"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return gen.generateKey()
    }

    private fun enc(plain: String): String? = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
    } catch (e: Exception) { null }

    private fun dec(blob: String): String? = try {
        val parts = blob.split(":")
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
        String(c.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), Charsets.UTF_8)
    } catch (e: Exception) { null }

    @Synchronized
    fun get(p: SharedPreferences, name: String): String {
        val raw = p.getString(name, "") ?: ""
        if (raw.isEmpty()) return ""
        if (raw.startsWith(TAG)) return dec(raw.removePrefix(TAG)) ?: ""
        enc(raw)?.let { p.edit().putString(name, TAG + it).apply() } // old plain-text value: lock it up now
        return raw
    }

    @Synchronized
    fun put(p: SharedPreferences, name: String, value: String) {
        if (value.isEmpty()) { p.edit().putString(name, "").apply(); return }
        val e = enc(value)
        p.edit().putString(name, if (e != null) TAG + e else value).apply()
    }
}
