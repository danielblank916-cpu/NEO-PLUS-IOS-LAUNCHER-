package com.neo.plus.iosluancher

import android.Manifest
import kotlinx.coroutines.delay
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import androidx.compose.runtime.DisposableEffect
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.sin

private val UserBlueTop = Color(0xFF2E9BFF)
private val UserBlueBottom = Color(0xFF0A74F5)

/** The glowing assistant orb: used on the home screen and in the chat header. */
@Composable
fun AssistantOrb(size: Dp, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val angle by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "angle"
    )
    Box(modifier.size(size).clip(CircleShape).background(Color(0xFF0B0B1A)), contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxSize().graphicsLayer { rotationZ = angle }.background(
                Brush.sweepGradient(
                    listOf(
                        Color(0xFF3B82FF), Color(0xFFA855F7), Color(0xFFFF5CA8),
                        Color(0xFFFFB347), Color(0xFF34D5C9), Color(0xFF3B82FF)
                    )
                )
            )
        )
        Box(
            Modifier.size(size * 0.62f).clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.95f), Color.White.copy(alpha = 0.12f))))
        )
        Box(Modifier.fillMaxSize().border(0.8.dp, Color.White.copy(alpha = 0.35f), CircleShape))
    }
}

@Composable
private fun RoundIconButton(icon: ImageVector, desc: String, tint: Color = Color.White.copy(alpha = 0.85f), onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart), label = "phase"
    )
    Row(
        Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.16f)).padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        for (i in 0..2) {
            val a = 0.30f + 0.70f * (0.5f + 0.5f * sin((phase - i * 0.18f) * 2f * PI.toFloat()))
            Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White.copy(alpha = a)))
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val mine = m.fromUser
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        val shape = RoundedCornerShape(20.dp, 20.dp, if (mine) 6.dp else 20.dp, if (mine) 20.dp else 6.dp)
        val bg = when {
            mine -> Brush.verticalGradient(listOf(UserBlueTop, UserBlueBottom))
            m.error -> SolidColor(Color(0xFF7A2A2A).copy(alpha = 0.80f))
            else -> SolidColor(Color.White.copy(alpha = 0.16f))
        }
        Box(Modifier.widthIn(max = 310.dp).clip(shape).background(bg).padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(m.text, color = Color.White, fontSize = 16.sp, lineHeight = 22.sp)
        }
        m.notes.forEach { n ->
            Text(
                "✓ $n", color = Color.White.copy(alpha = 0.62f), fontSize = 12.sp,
                modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 4.dp)
            )
        }
    }
}

@Composable
private fun GlassField(value: String, onChange: (String) -> Unit, hint: String, password: Boolean = false) {
    Box(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp), 0.18f).padding(horizontal = 14.dp, vertical = 12.dp)) {
        if (value.isEmpty()) Text(hint, color = Color.White.copy(alpha = 0.45f), fontSize = 15.sp)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
            cursorBrush = SolidColor(Color.White),
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else KeyboardType.Ascii),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun SettingsSheet(a: AssistantViewModel, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var provider by remember { mutableStateOf(a.provider) }
    var key by remember { mutableStateOf(a.apiKey) }
    var model by remember { mutableStateOf(a.model) }
    var gender by remember { mutableStateOf(a.voiceGender) }
    var voiceKey by remember { mutableStateOf(a.voiceKey) }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).consumeTouches().noRipple(onDone),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(20.dp).fillMaxWidth().glass(RoundedCornerShape(28.dp), 0.30f).noRipple { }
                .verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("AI model", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Neo Plus Assistant chats through your own API key. The key stays on this phone and is only sent to the provider you pick.",
                color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, lineHeight = 18.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Provider.values().forEach { p ->
                    val sel = p == provider
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(50))
                            .background(if (sel) UserBlueBottom else Color.White.copy(alpha = 0.16f))
                            .clickable { provider = p }.padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(p.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
            GlassField(key, { key = it }, "API key", password = true)
            GlassField(model, { model = it }, "Model (default: ${provider.defaultModel})")
            Text("Voice", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("female" to "Female", "male" to "Male").forEach { (g, label) ->
                    val sel = g == gender
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(50))
                            .background(if (sel) UserBlueBottom else Color.White.copy(alpha = 0.16f))
                            .clickable { gender = g }.padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
            if (provider != Provider.GEMINI) {
                GlassField(voiceKey, { voiceKey = it }, "Gemini key for the natural voice (optional)", password = true)
            }
            Text(
                "The natural, human-sounding voice comes from Google’s Gemini speech and needs a Gemini key (a free one works). Without it, the phone’s own voice is used.",
                color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, lineHeight = 18.sp
            )
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.16f))
                    .clickable {
                        a.saveSettings(provider, key, model)
                        a.saveVoice(gender, voiceKey)
                        Speaker.speak(ctx, "Hi, I’m your Neo Plus assistant. How can I help you today?")
                    }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) { Text("Hear this voice", color = Color.White, fontSize = 15.sp) }
            Text(
                "Get a ${provider.label} key", color = Color(0xFF7DB8FF), fontSize = 14.sp,
                modifier = Modifier.clickable { ctx.safeStart(Intent(Intent.ACTION_VIEW, Uri.parse(provider.keyUrl))) }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.16f))
                        .clickable { onDone() }.padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Cancel", color = Color.White, fontSize = 15.sp) }
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(50)).background(UserBlueBottom)
                        .clickable { a.saveSettings(provider, key, model); a.saveVoice(gender, voiceKey); onDone() }.padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Save", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}

/** Full-screen assistant: chat like Gemini, control the phone like Siri. */
@Composable
fun AssistantOverlay(a: AssistantViewModel, apps: List<AppEntry>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    // Close itself after an action took the user to another app / screen
    val seenClose = remember { mutableIntStateOf(a.closeSignal) }
    LaunchedEffect(a.closeSignal) { if (a.closeSignal != seenClose.intValue) onClose() }

    LaunchedEffect(a.messages.size, a.busy) {
        val count = a.messages.size + if (a.busy) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    // In-app speech recognition: no Google dialog. The panel only shows what you say while you are speaking.
    var listening by remember { mutableStateOf(false) }
    var heard by remember { mutableStateOf("") }
    var alts by remember { mutableStateOf<List<String>>(emptyList()) }
    // Conversation mode: after the first question the mic stays on for follow-ups and turns itself off after
    // 10 seconds without a word (the countdown only runs while nothing is being said, thought or spoken).
    var keepListening by remember { mutableStateOf(false) }
    val voiceAt = remember { longArrayOf(0L) }
    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(ctx)) SpeechRecognizer.createSpeechRecognizer(ctx) else null
    }

    fun finishWith(text: String?) {
        BeepMute.restore(ctx)
        voiceAt[0] = System.currentTimeMillis()
        listening = false; heard = ""; alts = emptyList()
        if (!text.isNullOrBlank()) a.send(text.trim(), apps)
    }

    DisposableEffect(recognizer) {
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() { voiceAt[0] = System.currentTimeMillis() }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val l = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
                if (l.isEmpty()) return
                voiceAt[0] = System.currentTimeMillis()
                heard = l.first()
                alts = l.drop(1).distinct().take(2)
            }
            override fun onResults(results: Bundle?) {
                finishWith(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: heard)
            }
            override fun onError(error: Int) {
                BeepMute.restore(ctx)
                val partial = heard
                listening = false; heard = ""; alts = emptyList()
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        if (partial.isNotBlank()) a.send(partial.trim(), apps)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        keepListening = false
                        Toast.makeText(ctx, "Allow the microphone for Neo Plus to talk to me.", Toast.LENGTH_LONG).show()
                    }
                    SpeechRecognizer.ERROR_CLIENT -> Unit
                    else -> if (!keepListening) Toast.makeText(ctx, "I couldn’t hear that, try again.", Toast.LENGTH_SHORT).show()
                }
            }
        })
        onDispose { try { recognizer?.destroy() } catch (e: Exception) { }; BeepMute.restoreNow(ctx) }
    }

    fun startRecognizer() {
        val r = recognizer
        if (r == null) {
            Toast.makeText(ctx, "No speech recognizer is installed on this phone.", Toast.LENGTH_SHORT).show()
            return
        }
        Speaker.stop()
        heard = ""; alts = emptyList()
        BeepMute.mute(ctx)
        try {
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            )
            listening = true
        } catch (e: Exception) {
            listening = false
            BeepMute.restoreNow(ctx)
            Toast.makeText(ctx, "Couldn’t start listening.", Toast.LENGTH_SHORT).show()
        }
    }

    fun turnMicOff(announce: Boolean) {
        BeepMute.restore(ctx)
        keepListening = false
        try { recognizer?.cancel() } catch (e: Exception) { }
        listening = false; heard = ""; alts = emptyList()
        if (announce) Toast.makeText(ctx, "Mic off", Toast.LENGTH_SHORT).show()
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { voiceAt[0] = System.currentTimeMillis(); startRecognizer() }
        else { keepListening = false; Toast.makeText(ctx, "Allow the microphone for Neo Plus to talk to me.", Toast.LENGTH_LONG).show() }
    }

    fun listen() {
        if (listening || keepListening) { turnMicOff(false); return } // tapping the mic again switches it off
        keepListening = true
        voiceAt[0] = System.currentTimeMillis()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecognizer()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(keepListening) {
        while (keepListening) {
            delay(300)
            val now = System.currentTimeMillis()
            // Busy thinking, speaking the reply, or the user is mid-sentence: the 10 s countdown waits.
            if (a.busy || Speaker.speaking || (listening && heard.isNotBlank())) { voiceAt[0] = now; continue }
            if (now - voiceAt[0] >= 10_000L) { turnMicOff(true); break }
            // Reopen the mic for the next command once the reply is finished (or after a silent timeout).
            if (!listening && now - voiceAt[0] >= 700L) startRecognizer()
        }
    }

    fun submit() {
        if (input.isBlank()) return
        a.send(input, apps)
        input = ""
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.55f), Color.Black.copy(alpha = 0.74f))))
                .consumeTouches()
                .windowInsetsPadding(safeInsets())
                .imePadding()
        ) {
            // ---- header
            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 8.dp, top = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                AssistantOrb(32.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Neo Plus Assistant", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(
                        (if (a.configured) "${a.provider.label} · ${a.activeModel}" else "No AI model connected") + " · v3.5.9",
                        color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp, maxLines = 1
                    )
                }
                RoundIconButton(
                    if (a.speak) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                    if (a.speak) "Mute replies" else "Read replies aloud"
                ) { a.updateSpeak(!a.speak) }
                RoundIconButton(Icons.Filled.GraphicEq, "Floating assistant: listen over other apps") {
                    val r = PhoneActions.run(ctx, "listen", org.json.JSONObject().put("on", true), apps)
                    if (r.ok) onClose() else Toast.makeText(ctx, r.note, Toast.LENGTH_LONG).show()
                }
                RoundIconButton(Icons.Filled.Settings, "AI model settings") { showSettings = true }
                if (a.messages.isNotEmpty()) RoundIconButton(Icons.Filled.Delete, "Clear chat") { a.clear() }
                RoundIconButton(Icons.Filled.Close, "Close") { onClose() }
            }

            // ---- conversation
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (a.messages.isEmpty()) {
                    Column(
                        Modifier.fillMaxSize().padding(horizontal = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        AssistantOrb(92.dp)
                        Spacer(Modifier.height(20.dp))
                        Text("How can I help?", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Ask me anything, or tell me to open apps, call, message, set alarms and change phone settings.",
                            color = Color.White.copy(alpha = 0.62f), fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 20.sp
                        )
                        if (!a.configured) {
                            Spacer(Modifier.height(18.dp))
                            Box(
                                Modifier.glass(RoundedCornerShape(50), 0.26f).clickable { showSettings = true }
                                    .padding(horizontal = 20.dp, vertical = 10.dp)
                            ) { Text("Connect an AI model", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState, modifier = Modifier.fillMaxSize(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(a.messages, key = { it.id }) { m -> Bubble(m) }
                        if (a.busy) item(key = "typing") { TypingDots() }
                    }
                }
            }

            if (listening && heard.isNotBlank()) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                        .glass(RoundedCornerShape(22.dp), 0.20f).padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(heard, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    alts.forEach { alt ->
                        Text(
                            alt, color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp,
                            modifier = Modifier.padding(top = 8.dp).clickable {
                                try { recognizer?.cancel() } catch (e: Exception) { }
                                finishWith(alt)
                            }
                        )
                    }
                }
            }

            EnableAssistantBanner()
            // ---- input
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(
                    Modifier.weight(1f).glass(RoundedCornerShape(28.dp), 0.20f)
                        .padding(start = 18.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.weight(1f).padding(vertical = 10.dp)) {
                        if (input.isEmpty()) {
                            Text(if (listening) "Listening…" else "Ask Neo Plus Assistant", color = Color.White.copy(alpha = if (listening) 0.8f else 0.5f), fontSize = 16.sp)
                        }
                        BasicTextField(
                            value = input, onValueChange = { input = it }, maxLines = 4,
                            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                            cursorBrush = SolidColor(Color.White),
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { submit() }),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (input.isNotBlank()) {
                        Box(
                            Modifier.size(38.dp).clip(CircleShape)
                                .background(Brush.verticalGradient(listOf(UserBlueTop, UserBlueBottom)))
                                .clickable { submit() },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Color.White, modifier = Modifier.size(20.dp)) }
                    } else {
                        RoundIconButton(Icons.Filled.Mic, "Speak") { listen() }
                    }
                }
            }
        }

        if (showSettings) SettingsSheet(a) { showSettings = false }
    }
}
