# NEO PLUS IOS LUANCHER

iPhone-style Android launcher built with Kotlin + Jetpack Compose.

## Features
- **Real home screen**: scans every installed app, real icons (adaptive icons rendered as iOS squircles), real launching, auto-updates on install/uninstall.
- **Translucent**: wallpaper-theme window + frosted glass panels; optional window blur on Android 12+.
- **Dock**: 4 pinned apps (defaults to Phone / Messages / Browser / Camera). Long-press any app: shortcuts, Add/Remove from Dock, App Info, Uninstall.
- **Today View** (swipe right): clock, battery, calendar, storage widgets + real Android widgets via AppWidgetHost ("+ Widget", "Edit" to remove).
- **App Library** (swipe past the last page): auto categories, Recently Added, search, tap a category to open it.
- **Control Center**: swipe UP from the bottom, LEFT half of the screen. **Notification Centre**: swipe UP from the bottom, RIGHT half. Both are dark and blur the home page; swipe down or tap outside to close. Nothing opens from the top.
- **Spotlight search** (swipe down anywhere, or tap the Search pill above the dock): apps + web.
- Home button returns to the first page; Back is swallowed like a real launcher.

## Look & speed
- NEO PLUS logo as the app icon (adaptive, dark background, Apple-style squircle on supported launchers) and as a badge on the clock widget.
- Apple-style continuous-corner (squircle) icons, flat clean icons with no drop shadows, app zooms out of the icon you tap.
- Faster startup: icons are rendered in parallel, sized to your screen, and package changes are debounced.

## Build
JDK 17 + Android SDK 35, then `gradle assembleDebug`. The GitHub Actions workflow builds the APK and uploads it as an artifact.

## Setup on the phone
1. Install the APK, press Home, choose **NEO PLUS** and **Always**.
2. Accept the permission prompts on first launch.
3. For brightness/rotation, Focus mode and all-files access, tap the matching tile once - Android opens the page where you flip the switch.

## Real toggles (no Settings screens)
Wi-Fi, Bluetooth, Airplane, Mobile data, Dark mode and Low power switch directly. Each tries the normal Android API, then hidden
system APIs, then root. The app targets Android 9 behaviour so Android still allows Wi-Fi/Bluetooth switching for it.
- Stock Android 13/14 blocks Airplane and Mobile data for normal apps. They work with **root**, or when the APK is installed as a
  **system priv-app** (custom ROM): copy the APK to `/system/priv-app/NeoPlusLauncher/` and `rom/privapp-permissions-com.neo.plus.iosluancher.xml` to `/system/etc/permissions/`.
- Low power / Dark mode also work after one adb grant: `adb shell pm grant com.neo.plus.iosluancher android.permission.WRITE_SECURE_SETTINGS`.
- Notification Centre needs Notification access once (the panel shows a button for it).
