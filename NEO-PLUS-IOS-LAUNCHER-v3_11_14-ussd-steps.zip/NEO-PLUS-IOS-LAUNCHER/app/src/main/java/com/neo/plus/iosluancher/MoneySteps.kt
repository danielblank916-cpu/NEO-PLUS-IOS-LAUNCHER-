package com.neo.plus.iosluancher

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

/**
 * Per-network settings for step-by-step mobile-money transfers (Airtel Money, TNM Mpamba).
 * Saved in the same "neo_money" preferences as the plain USSD code.
 */
object MoneySteps {
    private const val PREFS = "neo_money"

    class Profile(val id: String, val label: String, val defaultCode: String)

    /** The start codes are only defaults: change them with money_setup {"network":"...","code":"*123#"} if yours differ. */
    val profiles = listOf(
        Profile("airtel", "Airtel Money", "*211#"),
        Profile("mpamba", "TNM Mpamba", "*444#")
    )

    fun normalize(raw: String): String? {
        val s = raw.lowercase()
        return when {
            s.contains("airtel") -> "airtel"
            s.contains("mpamba") || s.contains("tnm") -> "mpamba"
            else -> null
        }
    }

    fun profile(id: String): Profile? = profiles.firstOrNull { it.id == id }
    fun label(id: String): String = profile(id)?.label ?: id

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun simFor(ctx: Context, id: String): Int = prefs(ctx).getInt("sim_$id", 0)
    fun startCode(ctx: Context, id: String): String =
        prefs(ctx).getString("code_$id", "").orEmpty().ifBlank { profile(id)?.defaultCode.orEmpty() }

    /** National 9-digit numbers start with these digits (088... = 88, 099... = 99). Change with money_setup "prefixes". */
    private val defaultPrefixes = mapOf("airtel" to "99,98", "mpamba" to "88,84")

    fun prefixes(ctx: Context, id: String): List<String> =
        prefs(ctx).getString("prefix_$id", "").orEmpty().ifBlank { defaultPrefixes[id].orEmpty() }
            .split(',').map { it.trim().trimStart('0') }.filter { it.isNotEmpty() }

    /** Which mobile money the recipient's number belongs to, or null when the prefix is unknown or listed for both. */
    fun networkForNumber(ctx: Context, digits: String): String? {
        val d = digits.filter { it.isDigit() }
        if (d.length < 9) return null
        val national = d.takeLast(9)
        val hits = profiles.filter { pr -> prefixes(ctx, pr.id).any { national.startsWith(it) } }
        return if (hits.size == 1) hits[0].id else null
    }

    /** true = with the cashout (withdrawal) fee, false = without, null = the user did not say. */
    fun parseFee(a: JSONObject): Boolean? {
        val raw = a.optString("fee").trim().lowercase()
        if (raw.isNotEmpty()) {
            return when {
                raw.contains("without") || raw.startsWith("no") || raw == "false" -> false
                raw.contains("with") || raw == "yes" || raw == "true" -> true
                else -> null
            }
        }
        return if (a.has("with_fee")) a.optBoolean("with_fee") else null
    }

    /** money_setup with a network: which SIM it is on, its start code and the number prefixes that belong to it. */
    fun setup(ctx: Context, a: JSONObject): String {
        val id = normalize(a.optString("network")) ?: return "Which network is it for: Airtel Money or Mpamba?"
        val e = prefs(ctx).edit()
        if (a.has("sim")) {
            val s = a.optInt("sim", 0)
            if (s !in 0..2) return "The SIM must be 1 or 2."
            e.putInt("sim_$id", s)
        }
        val code = a.optString("code").trim()
        if (code.isNotEmpty()) {
            if (!Regex("^\\*[0-9*]{2,12}#$").matches(code)) return "Couldn’t save that code. It should look like *211# (digits and stars only, no PIN)."
            e.putString("code_$id", code)
        }
        val pre = a.optString("prefixes").replace(" ", "")
        if (pre.isNotEmpty()) {
            if (!Regex("^[0-9]{2,3}(,[0-9]{2,3})*$").matches(pre)) return "Couldn’t save the prefixes. Give them like 88,84 (the digits after the 0)."
            e.putString("prefix_$id", pre)
        }
        e.apply()
        val sim = prefs(ctx).getInt("sim_$id", 0)
        return "Saved for ${label(id)}: start code ${startCode(ctx, id)}, " + (if (sim in 1..2) "SIM $sim" else "default SIM") +
            ", numbers starting 0" + prefixes(ctx, id).joinToString(", 0") + "."
    }
}

/**
 * Drives the network's USSD pop-ups after the user tapped Authorise: reads each screen, recognises it, types the
 * answer (a menu number found by its label, the recipient number, the amount) and presses Send. It STOPS at the PIN
 * screen: it never types a PIN, never presses anything on that screen (except Cancel when the amount or number shown
 * there does not match what the user authorised), and it never types into a password-style box.
 * Menus are answered by the WORDS of the option ("Send Money", "Without Cashout Fees"), not by fixed digits, and each
 * kind of screen is used once, so a changed menu order or a repeated screen cannot send it in circles. Anything it does
 * not recognise ends the automation and leaves the screen to the user.
 */
object UssdFlow {
    private val main = Handler(Looper.getMainLooper())

    /** A kind of screen. menu = which option to pick (found by its label); input = what to type in the box. */
    private class Rule(
        val key: String, val screen: Regex,
        val menu: ((MoneySender.Pending) -> Regex)? = null,
        val input: ((MoneySender.Pending) -> String)? = null
    )

    private class Screen(val msg: String, val edit: AccessibilityNodeInfo?, val send: AccessibilityNodeInfo?, val cancel: AccessibilityNodeInfo?)

    private val pinRe = Regex("(?i)enter\\s+(?:your\\s+)?pin")
    private val errorRe = Regex("(?i)\\b(invalid|insufficient|failed|failure|error|not registered|unsuccessful|declined|try again|incorrect|not allowed|limit)\\b")
    private val safeAnswer = Regex("^[0-9]{1,15}(\\.[0-9]{1,2})?$")
    private val optionRe = Regex("^\\s*(\\d{1,2})\\s*[.)\\-:]?\\s*(.+?)\\s*$")
    private val shownRe = Regex("(?is)(?:mwk|mk)\\s*([\\d,]+(?:\\.\\d+)?)\\s*to\\s*\\+?(\\d{7,15})")
    private val nameRe = Regex("(?is)to\\s*\\+?\\d{7,15}\\s*,\\s*([^.]+)\\.")
    private val chargeRe = Regex("(?is)service\\s*charge\\s*(?:mwk|mk)\\s*([\\d,]+(?:\\.\\d+)?)")
    private const val MAX_ACTIONS = 10

    private fun local(number: String) = "0" + number.filter { it.isDigit() }.takeLast(9)

    private fun rules(p: MoneySender.Pending, destAirtel: Boolean): List<Rule> = when (p.network) {
        "mpamba" -> listOf(
            Rule("main", Regex("(?is)^\\s*mpamba\\W+main\\s*menu"), menu = { Regex("(?i)send\\s*money") }),
            Rule("how", Regex("(?is)enter\\s*phone\\s*number.*favourites"), menu = { Regex("(?i)enter\\s*phone\\s*number") }),
            Rule("dest", Regex("(?is)please\\s*select.*\\bmpamba\\b.*airtel\\s*money"), menu = { if (destAirtel) Regex("(?i)^airtel\\s*money\\s*$") else Regex("(?i)^mpamba\\s*$") }),
            Rule("wallet", Regex("(?is)please\\s*select.*\\bwallet\\b.*favourites"), menu = { Regex("(?i)^wallet\\s*$") }),
            Rule("fee", Regex("(?is)cash\\s*out\\s*fees"),
                menu = { if (it.withFee) Regex("(?i)^with\\s+cash\\s*out") else Regex("(?i)^without\\s+cash\\s*out") }),
            Rule("number", Regex("(?is)^\\s*enter\\s*(?:(?:phone|airtel|mpamba)\\s*)?number\\s*:?"), input = { local(it.number) }),
            Rule("amount", Regex("(?is)^\\s*enter\\s*amount"), input = { it.amount })
        )
        "airtel" -> listOf(
            Rule("main", Regex("(?is)^\\s*airtel\\s*money.*send\\s*money"), menu = { Regex("(?i)send\\s*money") }),
            Rule("to", Regex("(?is)select\\s*:.*airtel\\s*number"),
                menu = { if (it.withFee) Regex("(?i)with\\s+withdrawal") else Regex("(?i)^airtel\\s+number\\s*$") }),
            Rule("how", Regex("(?is)^\\s*1\\s*[.)]?\\s*enter\\s*phone\\s*number.*favourites"), menu = { Regex("(?i)^enter\\s*phone\\s*number") }),
            Rule("number", Regex("(?is)^\\s*enter\\s*(?:phone|airtel)\\s*number\\s*:?"), input = { local(it.number) }),
            Rule("amount", Regex("(?is)^\\s*enter\\s*amount"), input = { it.amount })
        )
        else -> emptyList()
    }

    /** The number in front of the option whose label matches, e.g. "2.Airtel with withdrawal fee" -> "2". */
    private fun optionNumber(msg: String, label: Regex): String? {
        for (line in msg.lines()) {
            val m = optionRe.find(line) ?: continue
            if (label.containsMatchIn(m.groupValues[2].trim())) return m.groupValues[1]
        }
        return null
    }

    private var cur: MoneySender.Pending? = null
    private var list: List<Rule> = emptyList()
    private val used = HashSet<String>()
    private var startedAt = 0L
    private var lastDoneMsg = ""
    private var lastProgressAt = 0L
    private var unknownSince = 0L
    private var gen = 0

    /** Called right after the network's code was dialled. */
    fun begin(ctx: Context, p: MoneySender.Pending) {
        val app = ctx.applicationContext
        main.post {
            val now = System.currentTimeMillis()
            cur = p; list = rules(p, MoneySteps.networkForNumber(app, p.number) == "airtel"); used.clear()
            startedAt = now; lastProgressAt = now; lastDoneMsg = ""; unknownSince = 0L
            val g = ++gen
            main.postDelayed({ tick(app, g) }, 1200)
        }
    }

    private fun finish(app: Context, text: String) {
        cur = null; gen++
        Announcer.say(app, text)
    }

    private fun later(app: Context, g: Int, ms: Long) { main.postDelayed({ tick(app, g) }, ms) }

    private fun tick(app: Context, g: Int) {
        if (g != gen) return
        val p = cur ?: return
        val now = System.currentTimeMillis()
        if (now - startedAt > 120_000L) { finish(app, "Stopped: the network took too long. Nothing is sent until you enter your PIN."); return }
        val svc = IosControlService.instance
            ?: run { finish(app, "Stopped: turn on NEO PLUS iOS Controls in Settings > Accessibility."); return }
        val s = read(svc.rootInActiveWindow, app.packageName)
        if (s == null || s.msg.isEmpty()) { later(app, g, 350); return }

        if (s.msg == lastDoneMsg) { // answered already, waiting for the next screen
            if (now - lastProgressAt > 25_000L) finish(app, "Stopped: the network did not move on. The screen is yours.") else later(app, g, 350)
            return
        }
        if (pinRe.containsMatchIn(s.msg)) { handOver(app, p, s); return }

        val rule = list.firstOrNull { it.key !in used && it.screen.containsMatchIn(s.msg) }
        if (rule != null && used.size < MAX_ACTIONS) { unknownSince = 0L; act(app, g, p, rule, s); return }

        if (errorRe.containsMatchIn(s.msg)) { finish(app, "Stopped. The network says: ${s.msg.replace('\n', ' ').take(120)}"); return }
        if (unknownSince == 0L) unknownSince = now
        if (now - unknownSince > 4_000L) {
            finish(app, "Stopped: I did not recognise this screen, so I left it for you.")
            return
        }
        later(app, g, 350)
    }

    private fun act(app: Context, g: Int, p: MoneySender.Pending, rule: Rule, s: Screen) {
        val edit = s.edit
        if (edit == null || s.send == null || edit.isPassword) { finish(app, "Stopped: this screen has no normal input box, so I left it for you."); return }
        val answer = when {
            rule.menu != null -> optionNumber(s.msg, rule.menu.invoke(p))
            rule.input != null -> rule.input.invoke(p)
            else -> null
        }
        if (answer == null) { finish(app, "Stopped: I could not find the right option on this menu, so I left it for you."); return }
        if (!safeAnswer.matches(answer)) { finish(app, "Stopped: the answer for this step was not valid."); return }
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, answer) }
        if (!edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) { finish(app, "Stopped: I could not type into this screen."); return }
        main.postDelayed({
            if (g != gen) return@postDelayed
            val svc = IosControlService.instance
            val s2 = if (svc != null) read(svc.rootInActiveWindow, app.packageName) else null
            // still the same screen, with exactly the answer typed in, before anything is pressed
            if (s2 == null || s2.msg != s.msg || s2.send == null || s2.edit?.text?.toString() != answer) {
                finish(app, "Stopped: the screen changed while I was typing, so I left it for you.")
                return@postDelayed
            }
            if (!s2.send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { finish(app, "Stopped: I could not press Send."); return@postDelayed }
            used += rule.key
            lastDoneMsg = s.msg
            lastProgressAt = System.currentTimeMillis()
            later(app, g, 700)
        }, 300)
    }

    /** The PIN screen: check what it shows against what the user authorised, then leave it to the user. */
    private fun handOver(app: Context, p: MoneySender.Pending, s: Screen) {
        val feeAsked = "fee" in used || "to" in used
        cur = null; gen++
        val m = shownRe.find(s.msg)
        if (m == null) {
            Announcer.say(app, "I could not read the amount and number on the PIN screen. Check them yourself before you enter your PIN.")
            return
        }
        val amount = m.groupValues[1].replace(",", "").toBigDecimalOrNull()
        val wanted = p.amount.toBigDecimalOrNull()
        val amountOk = amount != null && wanted != null && amount.compareTo(wanted) == 0
        val shownNum = m.groupValues[2]
        val numberOk = shownNum.takeLast(9) == p.number.takeLast(9)
        if (!amountOk || !numberOk) {
            s.cancel?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Announcer.say(app, "Stopped and cancelled. The PIN screen showed MK ${m.groupValues[1]} to ending ${shownNum.takeLast(3)}, which is not what you authorised.")
            return
        }
        val name = nameRe.find(s.msg)?.groupValues?.get(1)?.trim().orEmpty()
        val charge = chargeRe.find(s.msg)?.groupValues?.get(1).orEmpty()
        val who = if (name.isNotEmpty()) name else p.name
        val fee = if (feeAsked) (if (p.withFee) ", with the cashout fee" else ", without the cashout fee")
                  else ". Note: the network did not ask about the cashout fee, so your choice was not applied"
        Announcer.say(app, "Ready. Enter your PIN to send ${p.currency} ${p.amount} to $who$fee" +
            (if (charge.isNotEmpty()) ", service charge $charge" else "") + ".")
    }

    /** The visible text of a USSD pop-up (without its input box and buttons) plus the input box and the Send / Cancel buttons. */
    private fun read(root: AccessibilityNodeInfo?, ownPkg: String): Screen? {
        if (root == null) return null
        if (root.packageName?.toString() == ownPkg) return null
        val texts = ArrayList<String>()
        var edit: AccessibilityNodeInfo? = null
        var send: AccessibilityNodeInfo? = null
        var cancel: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 12) return
            val cls = n.className?.toString().orEmpty()
            val t = n.text?.toString()?.trim().orEmpty()
            when {
                cls.endsWith("EditText") -> if (edit == null) edit = n
                cls.endsWith("Button") -> {
                    if (t.equals("send", true) || t.equals("ok", true)) { if (send == null) send = n }
                    else if (t.equals("cancel", true)) { if (cancel == null) cancel = n }
                }
                t.isNotEmpty() -> texts += t
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        if (edit == null && send == null) return null // not a USSD pop-up
        return Screen(texts.joinToString("\n").trim(), edit, send, cancel)
    }
}
